import {LuaEngineClientSdk} from "./LuaEngineClientSdk.ts";

const LuaEngine = new LuaEngineClientSdk("ws://localhost:3030/ws");


export default LuaEngine;
