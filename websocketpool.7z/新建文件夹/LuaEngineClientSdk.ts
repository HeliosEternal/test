import {Header, MessageBodyBuilder, WSMessage} from "./model/ws-message";
import {
    RequestBodyBuilder,
    ScriptFileSourceType,
    ScriptFileSourceTypeBuilder,
    ScriptFunctionTask
} from "./model/request";
import WebSocketPool from "./WebSocketPool.ts";

// const encoder = new Encoder();


export class LuaEngineClientSdk {

    private webSocketPool!: WebSocketPool;

    public constructor(url: string) {
        this.webSocketPool = new WebSocketPool(url);
    }

    sendWebsocketMessage(wsMessage: WSMessage, isStream: boolean): Promise<any> {
        return this.webSocketPool.sendWebsocketMessage(wsMessage, isStream);
    }


    public callBuiltinScript(file_name: string, function_name: string, function_param: Object): Promise<any> {
        let script_file_source_type = ScriptFileSourceTypeBuilder.builtin(file_name)
        return this.callScript(script_file_source_type, function_name, function_param);
    }

    public callRelativeScript(file_name: string, function_name: string, function_param: Object): Promise<any> {
        let script_file_source_type = ScriptFileSourceTypeBuilder.relative(file_name)
        return this.callScript(script_file_source_type, function_name, function_param);
    }

    public callAbsoluteScript(file_name: string, function_name: string, function_param: Object): Promise<any> {
        let script_file_source_type = ScriptFileSourceTypeBuilder.absolute(file_name)
        return this.callScript(script_file_source_type, function_name, function_param);
    }

    public callHttpScript(file_name: string, function_name: string, function_param: Object): Promise<any> {
        let script_file_source_type = ScriptFileSourceTypeBuilder.http(file_name)
        return this.callScript(script_file_source_type, function_name, function_param);
    }

    public callTextScript(file_name: string, function_name: string, function_param: Object): Promise<any> {
        let script_file_source_type = ScriptFileSourceTypeBuilder.text(file_name)
        return this.callScript(script_file_source_type, function_name, function_param);
    }

    private async callScript(script_file_source_type: ScriptFileSourceType, function_name: string, function_param: Object): Promise<any> {
        let header = new Header("com.miniapp");
        let script_function_task = new ScriptFunctionTask(script_file_source_type, function_name, function_param);
        let requestBody = RequestBodyBuilder.CallScript(script_function_task);
        let messageBody = MessageBodyBuilder.Request(requestBody);
        let wsMessage = new WSMessage(header, "/call-script", messageBody);
        return this.sendWebsocketMessage(wsMessage, false);
    }

}


