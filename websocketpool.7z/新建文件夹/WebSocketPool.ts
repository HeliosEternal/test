import {WSMessage} from "./model/ws-message.ts";
import {ResponseBody} from "./model/response.ts";
import {th} from "vuetify/locale";

type Connection = { id: number, worker: Worker, inUse: boolean, lastUsed: number };
type ResolveFunction = (value?: any) => void;
type RejectFunction = (reason?: any) => void;
type QueueItem = {
    resolve: ResolveFunction;
    reject: RejectFunction;
};

type  ResponseMessageCallbackObject = {
    resolve: (value?: any) => void;
    reject: (reason?: any) => void;
    isStream: boolean;
    startTime: number;
}


class WebSocketPool {
    // 连接url
    private serverUrl: string;
    // 最小连接数，初始化会创建的连接数
    private minSize: number;
    // 扩容的最大连接数
    private maxSize: number;
    // 空闲时间就回收，默认是超过30S
    private idleTimeout: number;
    // 扩容比例，80%都在忙碌的时候考虑扩容
    private scaleUpThreshold: number;
    // 空闲比例高于20%的时候，开始回收
    private scaleDownThreshold: number;
    // 连接池
    private poolMap: Map<number, Connection>;
    // 请求新的连接队列
    private queue: QueueItem [];
    // 空闲调度句柄id
    private idleInterval: number;
    // 动态伸缩句柄id
    private scaleInterval: number;

    private responseCallBackMap: Map<string, ResponseMessageCallbackObject>;

    private currentIndex: number = 0;

    constructor(serverUrl: string, minSize = 5, maxSize = 5, idleTimeout = 30000, scaleUpThreshold = 0.8, scaleDownThreshold = 0.2) {
        this.serverUrl = serverUrl;
        this.minSize = minSize;
        this.maxSize = maxSize;
        this.idleTimeout = idleTimeout;
        this.scaleUpThreshold = scaleUpThreshold; // 当池中空闲连接比例低于80%时，考虑扩容
        this.scaleDownThreshold = scaleDownThreshold; // 当池中空闲连接比例高于20%时，考虑回收
        this.poolMap = new Map();
        this.queue = [];
        this.idleInterval = 0;
        this.scaleInterval = 0;
        this.responseCallBackMap = new Map();
        this._initializePool();
        // this.startIdleCheck();
        // this.startScaleMonitor();
    }

    _initializePool() {
        for (let i = 0; i < this.minSize; i++) {
            this._createConnection();
        }
    }

    _createConnection(): Promise<Connection> {
        return new Promise((resolve, reject) => {
            // 如果创建的连接大于当前池子的连接，则返回null，不能再创建了
            if (this.poolMap.size >= this.maxSize) return null;
            // 创建一个线程 web worker
            const worker = new Worker(new URL("./work/WebsocketWorker.ts", import.meta.url));
            // 接收来自 web worker websocket发来的消息
            worker.onmessage = (event) => {
                const {type, payload} = event.data;
                switch (type) {
                    case 'open':
                        console.log('WebSocket 连接已建立. id:', payload.id);
                        let connection = this.onOpenWebsocket(payload.id, worker);
                        resolve(connection);
                        break;
                    case 'message':
                        console.log("receiver message from websocket: ", JSON.parse(payload.data))
                        this.onMessageWebsocket(payload);
                        break;
                    case 'close':
                        console.log('WebSocket 连接已关闭. id:', payload.id);
                        this.onCloseWebsocket(payload);
                        reject("error");
                        break;
                    case 'error':
                        console.log('WebSocket 异常错误. id:', payload.id)
                        break
                    default:
                        console.error('Unknown message type:', type, " id:", payload.id);
                        break
                }
            }
            worker.postMessage({type: 'connect', payload: {id: simpleUniqueId(), url: this.serverUrl}});
            // 避免长时间阻塞，超时返回错误
            setTimeout(() => {
                reject(new Error('Promise timed out'));
            }, 15000);
        });
    }

    onOpenWebsocket(id: number, worker: Worker): Connection {
        const connection: Connection = {
            id,
            worker,
            inUse: false,
            lastUsed: Date.now(),
        };
        this.poolMap.set(id, connection);
        return connection;
    }

    onCloseWebsocket(payload: any) {
        let id = payload.id;
        // 移除关闭的 worker
        this.poolMap.delete(id)
        // 尝试创建新的连接以维持初始池大小
        if (this.poolMap.size < this.minSize) {
            this._createConnection().catch((error) => {
                console.log("_createConnection error : ", error);
            });
        }
    }

    onMessageWebsocket(payload: any) {
        let responseWSMessage: WSMessage = JSON.parse(payload.data) as WSMessage;
        let requestId: string = responseWSMessage.header.request_id;
        let callbackObject: ResponseMessageCallbackObject | undefined = this.responseCallBackMap.get(requestId);
        if (!callbackObject) {
            console.log("can not find callback id: ", requestId);
            return;
        }
        let startTime = callbackObject.startTime;
        let endTime = new Date().getTime();
        //console.log("====> 耗时 response time: ", performance.now() - callbackObject.startTime);
        console.log("脚本耗时：", "msg_id:", requestId, "startTime:", startTime, "endTime:", endTime, "costTime:", endTime - startTime, "ms");

        let responseBody: ResponseBody = responseWSMessage.body.content as ResponseBody;
        if (responseBody.code !== 200) {
            callbackObject.reject({
                "code": responseBody.code,
                "msg": responseBody.msg
            });
            return;
        }
        let data: any = responseBody.data?.content
        callbackObject.resolve(data);
        if (!callbackObject.isStream) {
            this.responseCallBackMap.delete(requestId);
        }
    }


    closeConnection(conn: Connection) {
        if (conn) {
            conn.worker.postMessage({type: 'close', id: conn.id});
        }
    }

    public async sendWebsocketMessage(wsMessage: WSMessage, isStream: boolean): Promise<void> {
        let id: number;
        return new Promise((resolve, reject) => {
            //const startTime = performance.now();
            const startTime = new Date().getTime();
            this.responseCallBackMap.set(wsMessage.header.request_id, {resolve, reject, isStream, startTime});

            let connection: Connection | undefined = this.getConnection();
            console.log("sendWebsocketMessage: id: ", connection?.id);
            connection?.worker.postMessage({type: 'send', payload: wsMessage});

          /*  this.acquire().then((connection: Connection) => {
                id = connection.id
                console.log("sendWebsocketMessage: id: ", id);
                connection.worker.postMessage({type: 'send', payload: wsMessage});
                // 这里发送完成消息，需要等待响应，不能调用 resolve(); 我们已经存入到responseCallBackMap中，等消息返回响应的时候再回调返回
            }).catch((error) => {
                console.error("sendWebsocket error: ", error);
                reject(error);
            }).finally(() => {
                console.log("发送完毕： wsMessage:", wsMessage);
                // 归还连接
                if (id) {
                    this.release(id)
                }
            })*/
        });
    }


    getConnection(): Connection | undefined {
        let values = Array.from(this.poolMap.values());
        if (this.currentIndex >= values.length) {
            this.currentIndex = values.length - 1;
        }
        const server = values[this.currentIndex];
        this.currentIndex = (this.currentIndex + 1) % values.length; // 轮询索引
        return server;
    }

    async acquire(): Promise<Connection> {
        return new Promise((resolve, reject) => {
            // 查找空闲连接
            const available = Array.from(this.poolMap.values()).find((value) => !value.inUse);
            if (available) {
                available.inUse = true;
                available.lastUsed = Date.now();
                resolve(available);
                // 如果空闲连接使用尽，需要创建新的连接
            } else if (this.poolMap.size < this.maxSize) {
                // 创建新连接
                this._createConnection().then((newConn) => {
                    newConn.inUse = true;
                    newConn.lastUsed = Date.now();
                    resolve(newConn);
                }).catch((error) => {
                    reject(error);
                });
                // 连接已经用满了，需要等待释放其他的连接，先放入队列，等待释放之后再获取使用
            } else {
                // 将请求加入队列
                this.queue.push({resolve, reject});
            }
            // 避免长时间阻塞，超时返回错误
            setTimeout(() => {
                reject(new Error('Promise timed out, can not find available Connection'));
            }, 15000);
        });
    }

// 释放连接, 如果队列有等待的请求，正好可以给它使用
    release(id
                :
                number
    ) {
        if (!id) {
            return;
        }
        const connection = this.poolMap.get(id);
        if (connection) {
            connection.inUse = false;
            connection.lastUsed = Date.now();
            // 处理队列中的请求
            if (this.queue.length > 0) {
                const item = this.queue.shift();
                if (item) {
                    connection.inUse = true;
                    connection.lastUsed = Date.now();
                    item.resolve(connection);
                }
            }
        }
    }

// 定期检查并回收空闲连接
    startIdleCheck() {
        this.idleInterval = setInterval(() => {
            const now = Date.now();
            this.poolMap.forEach(conn => {
                if (!conn.inUse && (now - conn.lastUsed) > this.idleTimeout && this.poolMap.size > this.minSize) {
                    this.closeConnection(conn);
                }
            });
        }, this.idleTimeout);
    }

// 定期监测负载并动态调整连接数
    startScaleMonitor() {
        this.scaleInterval = setInterval(() => {
            const idleConnections = Array.from(this.poolMap.values()).filter((value) => !value.inUse);
            const idleRatio = idleConnections.length / this.poolMap.size;
            if (idleRatio < this.scaleUpThreshold && this.poolMap.size < this.maxSize) {
                // 扩容
                this._createConnection();
                console.log('连接池扩容');
            }
            if (idleRatio > this.scaleDownThreshold && this.poolMap.size > this.minSize) {
                // 回收连接
                idleConnections.forEach(conn => {
                    if (this.poolMap.size <= this.minSize) return;
                    this.closeConnection(conn);
                    console.log('连接池回收一个连接');
                });
            }
        }, 10000); // 每10秒检查一次
    }

    stop() {
        clearInterval(this.idleInterval);
        clearInterval(this.scaleInterval);
        this.poolMap.forEach(conn => {
            this.closeConnection(conn);
        });
        this.poolMap.clear();
        this.queue = [];
    }
}

function simpleUniqueId() {
    return 'uid-' + Math.random().toString(36).slice(2, 11);
}


export default WebSocketPool;