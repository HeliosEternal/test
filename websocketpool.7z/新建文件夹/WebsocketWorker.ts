let websocket: WebSocket;
let id: string;
self.onmessage = function (event) {
    const {type, payload} = event.data;
    switch (type) {
        case 'connect':
            connect(payload);
            break;
        case 'send':
            sendWebsocketMessage(payload)
            break;
        case 'close':
            closeWebsocket();
            break;
        default:
            console.error('Unknown message type:', type);
    }
};

function connect(payload: any) {
    id = payload.id;
    websocket = new WebSocket(payload.url);
    websocket.onopen = function () {
        self.postMessage({
            type: 'open', payload: {
                id: id,
            }
        });
    };
    websocket.onmessage = function (event) {
        self.postMessage({
            type: 'message', payload: {
                data: event.data,
                id: id,
            }
        });
    };
    websocket.onerror = function (event) {
        self.postMessage({
            type: 'error', payload: {
                id: id,
            }
        });
    }
    websocket.onclose = function () {
        self.postMessage({
            type: 'close', payload: {
                id: id
            }
        });
    };
}

function sendWebsocketMessage(payload: any) {
    if (websocket && websocket.readyState === WebSocket.OPEN) {
        websocket.send(JSON.stringify(payload));
    } else {
        self.postMessage({
            type: 'error', payload: {
                id: id,
                message: 'Websocket is not connected, can not send message'
            }
        });
        console.error('Websocket is not connected, can not send message, id:', id);
    }
}

function closeWebsocket() {
    if (websocket) {
        websocket.close();
    }
}