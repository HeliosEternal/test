mod protocol;
mod model;
mod server;
mod util;
pub mod init;

fn main() {
    println!("Hello, world!");
}
