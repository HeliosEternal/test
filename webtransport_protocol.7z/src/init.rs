use tracing::level_filters::LevelFilter;
use tracing_subscriber::FmtSubscriber;

pub fn init_log() {
    // 初始化日志层，设置日志级别为 DEBUG
    let subscriber = FmtSubscriber::builder()
        .with_max_level(LevelFilter::INFO)
        .finish();
    tracing::subscriber::set_global_default(subscriber).expect("Setting default subscriber failed");
}