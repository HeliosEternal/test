use crate::model::binary_stream_file::ByteArrayMultipartFile;
use crate::model::message::FileStreamChunkData;
use crate::model::response_payload::FileChunkAck;
use crate::util::hash_util;
use bytes::BytesMut;
use dashmap::DashMap;
use moka::future::Cache;
use std::sync::Arc;
use std::time::Duration;
use tracing::error;

/// 这个文件是处理文件分块存储和拼接成完整的文件
///

/// 缓存 appId+requestId 的文件分块任务  moka缓存的异步版本需要支持value支持clone 所以需要使用Arc包裹
lazy_static::lazy_static! {
static ref GLOBAL_FILE_CHUNK_MANAGER_CACHE: Cache<String, Arc<FileChunkData>> ={
 let cache = Cache::builder()
  .max_capacity(200)
  .time_to_live(Duration::from_secs(60 * 10))
  .time_to_idle(Duration::from_secs(60 * 5))
  .build();
cache
};
}

pub struct FileChunkData {
    // 文件总数
    pub total_files: usize,
    // key 是 file_index+chunk_index
    pub file_chunk_data_map: DashMap<String, FileStreamChunkData>,
}

pub async fn add_file_chunk_data(
    app_id: &str,
    request_id: &str,
    chunk_data: FileStreamChunkData,
) -> FileChunkAck {
    let total_files = chunk_data.total_files;
    let file_index = chunk_data.file_index;
    let chunk_index = chunk_data.chunk_index;
    let is_last_chunk = chunk_data.is_last_chunk;

    if chunk_data.chunk_binary_stream.is_none() {
        return FileChunkAck::build_error_ack(
            file_index,
            chunk_index,
            "file stream binary is none",
        );
    }

    // 获取二进制数组的引用
    let binary_byte = chunk_data.chunk_binary_stream.as_ref();
    let is_valid =
        validate_file_stream_metadata(binary_byte.unwrap(), chunk_data.chunk_hash.as_str());
    // 验证 hash是否有效
    if !is_valid {
        return FileChunkAck::build_error_ack(
            file_index,
            chunk_index,
            "file stream metadata is none",
        );
    }

    // 将分块数据存储到缓存中
    let key = format!("{}_{}", app_id, request_id);
    let entry = GLOBAL_FILE_CHUNK_MANAGER_CACHE
        .entry(key)
        .or_insert_with(async {
            Arc::new(FileChunkData {
                total_files,
                file_chunk_data_map: DashMap::new(),
            })
        })
        .await;

    let chunk_key = format!("{}_{}", file_index, chunk_index);
    entry
        .value()
        .file_chunk_data_map
        .insert(chunk_key, chunk_data);
    // 当分块存储完毕，需要构建一个ACK消息 响应给对方
    let file_chunk_ack = FileChunkAck::new(chunk_index, file_index, is_last_chunk, true, None);
    file_chunk_ack
}

/// 组装完成的文件数据，需要你判断文件分块是否传输完整，再调用本函数可以拼接完整的文件。
pub async fn assemble_complete_file_stream(
    app_id: &str,
    request_id: &str,
) -> Option<Vec<ByteArrayMultipartFile>> {
    // 获取缓存中的分块数据
    let key = format!("{}_{}", app_id, request_id);
    let entry = GLOBAL_FILE_CHUNK_MANAGER_CACHE.get(&key).await;
    if entry.is_none() {
        return None;
    }
    let file_chunk_data = entry.unwrap();
    let mut vec_binary: Vec<ByteArrayMultipartFile> = Vec::new();

    let total_files = file_chunk_data.total_files;

    let mut file_chunk_map = &file_chunk_data.file_chunk_data_map;

    // 根据total_files 循环，依次获取每个文件的分块数据，并合并成一个完整的文件
    for file_index in 0..total_files {
        let mut file_byte = BytesMut::new();
        let mut chunk_index = 0;

        let mut file_type: String = String::new();
        let mut file_name: String = String::new();

        loop {
            // 获取分块数据
            let key = format!("{}_{}", file_index, chunk_index);
            let value_option = file_chunk_map.remove(&key);
            if value_option.is_none() {
                return None;
            }

            // 判断分块数据是否为空
            let entry = value_option.unwrap();
            let file_stream_chunk_data = entry.1;
            if file_stream_chunk_data.chunk_binary_stream.is_none() {
                error!("chunk stream binary is none");
                return None;
            }

            // 拼接分块数据
            let chunk_bytes = file_stream_chunk_data.chunk_binary_stream.as_ref().unwrap();
            file_byte.extend_from_slice(chunk_bytes);

            // 如果当前分块已经是最后一个分块，那么跳出循环
            if chunk_index <= file_stream_chunk_data.total_chunk - 1 {
                file_type = file_stream_chunk_data.file_type;
                file_name = file_stream_chunk_data.file_name;
                break;
            }
            chunk_index += 1;
        }
        let file_byte = ByteArrayMultipartFile {
            name: file_name,
            file_type,
            length: file_byte.len(),
            bytes: file_byte.to_vec(),
        };
        vec_binary.push(file_byte);
    }
    Some(vec_binary)
}

fn validate_file_stream_metadata(bytes: &[u8], chunk_hash_str: &str) -> bool {
    hash_util::hash_bytes(bytes) == chunk_hash_str
}
