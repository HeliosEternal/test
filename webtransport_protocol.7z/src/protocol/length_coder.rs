use byteorder::{BigEndian, ByteOrder};
use bytes::{BufMut, Bytes, BytesMut};
use thiserror::Error;
use x509_parser::nom::AsBytes;
use crate::model::message::WebDataMessage;

// 定义错误类型
#[derive(Debug, Error)]
pub enum DecodeError {
    #[error("无效的长度: {0}")]
    InvalidLength(usize),
    #[error("消息过长: {0}, 最大限制: {1}")]
    MessageTooLarge(usize, usize),
}

// 定义状态机状态
enum State {
    WaitingForLength,         // 等待长度字段
    WaitingForPayload(usize), // 等待消息体，参数为消息长度
}

// 解码器结构体
pub struct LengthDecoder {
    buffer: BytesMut,        // 内部缓冲区
    state: State,            // 当前状态
    max_message_size: usize, // 最大允许的消息大小
}

impl LengthDecoder {
    // 创建新的解码器实例，指定最大消息大小
    pub fn new(max_message_size: usize) -> Self {
        LengthDecoder {
            buffer: BytesMut::new(),
            state: State::WaitingForLength,
            max_message_size,
        }
    }

    // 将外部数据追加到内部缓冲区
    pub fn feed(&mut self, data: &[u8]) {
        self.buffer.extend_from_slice(data);
    }

    // 尝试解析所有完整的消息
    pub fn decode(&mut self) -> Result<Vec<Bytes>, DecodeError> {
        let mut messages = Vec::new();
        while let Some(message) = self.try_decode()? {
            messages.push(message);
        }
        Ok(messages)
    }

    // 尝试解码一条消息
    fn try_decode(&mut self) -> Result<Option<Bytes>, DecodeError> {
        match self.state {
            State::WaitingForLength => {
                if self.buffer.len() < 4 {
                    return Ok(None); // 数据不足
                }
                let length_bytes = self.buffer.split_to(4);
                let length = BigEndian::read_u32(&length_bytes) as usize;

                if length == 0 {
                    return Err(DecodeError::InvalidLength(length));
                }
                if length > self.max_message_size {
                    return Err(DecodeError::MessageTooLarge(length, self.max_message_size));
                }

                self.state = State::WaitingForPayload(length);
                self.try_decode()
            }
            State::WaitingForPayload(length) => {
                if self.buffer.len() < length {
                    return Ok(None); // 数据不足
                }

                let payload = self.buffer.split_to(length).freeze();
                self.state = State::WaitingForLength;

                Ok(Some(payload))
            }
        }
    }
}

// 将消息编码成带长度前缀的格式
pub fn encode_message(message: &WebDataMessage) -> anyhow::Result<Vec<u8>> {
    let message_bytes = rmp_serde::encode::to_vec(message)?;
    let len = message_bytes.len() as u32; // 获取消息体的长度
    let mut packet = Vec::new();
    packet.extend_from_slice(&len.to_be_bytes()); // 前4个字节是消息长度
    packet.extend_from_slice(message_bytes.as_slice()); // 添加消息内容
    Ok(packet)
}

#[test]
pub fn test1(){
    let mut decoder = LengthDecoder::new(1024*1024*10);


    let body: &str = "这是一句话，测试下二进制数组"; // 这是正文数据
    let body_len = body.len() as u32; // 计算正文的长度，假设使用u32表示长度

    let body1: &str = "我是正在发送的消息体内容"; // 这是正文数据
    let body_len1 = body1.len() as u32; // 计算正文的长度，假设使用u32表示长度

    // 创建一个BytesMut缓冲区
    let mut buf = BytesMut::with_capacity(4 + body_len as usize); // 4 字节用于长度，后面是正文

    // 写入长度信息（4字节，u32）
    buf.put_u32(body_len);
    // 写入正文数据
    buf.put(body.as_bytes());

    // 写入长度信息（4字节，u32）
    buf.put_u32(body_len1);
    // 写入正文数据
    buf.put(body1.as_bytes());

    decoder.feed(buf.as_bytes());

    let result = decoder.decode();

    if let Ok(vec_bytes) = result {
        vec_bytes.iter().for_each(|byte|{
            println!("{:?}", String::from_utf8_lossy(byte.as_bytes()));
        })
    }


}