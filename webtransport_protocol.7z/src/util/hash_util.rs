use blake2::{Blake2b512, Digest};

/// 获取给定输入字符串的 BLAKE2b512 哈希值，并将其转换为十六进制字符串。
/// Blake2b512 默认不是线程安全的。特别是 finalize_reset() 修改内部状态，因此不能在多个线程间共享使用。
/// 推荐方法是每个线程创建自己的哈希实例，以确保安全性并避免竞争条件。
/// 如果必须在多个线程中共享哈希对象，使用 Mutex 或其他同步机制来保护它的使用。
pub fn hash_str(input: &str) -> String {
    hash_bytes(input.as_bytes())
}

pub fn hash_bytes(input: &[u8]) -> String {
    // 哈希对象在使用过程中存储了当前哈希计算的状态，因此每次计算新哈希时，都需要重新创建一个新的实例。
    let mut hasher = Blake2b512::new();
    hasher.update(input);
    let result = hasher.finalize();
    hex::encode(result)
}
