use serde::{Deserialize, Serialize};
use strum::{Display, EnumString};

#[derive(Debug, Serialize, Deserialize, Clone)]
#[serde(tag = "type", content = "content")]
pub enum RequestBody {
    CallScript(ScriptFunctionTask),
    None,
}

impl RequestBody {
    pub fn get_json_data(&self) -> Option<Result<serde_json::Value, serde_json::error::Error>> {
        match self {
            RequestBody::CallScript(data) => Some(serde_json::to_value(data)),
            _ => None,
        }
    }
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct ScriptFunctionTask {
    /// lua 文件的相对路径
    pub script_file_source_type: ScriptFileSourceType,
    /// 需要调用的lua函数名称
    pub function_name: String,
    /// 函数参数，json数据，数组形式，支持多个参数
    pub function_param: serde_json::Value,
}

#[derive(Debug, Serialize, Deserialize, Clone, EnumString, Display)]
#[serde(tag = "type", content = "content")]
pub enum ScriptFileSourceType {
    // 内置本系统的不可修改脚本, 被编译在代码中，只读，无法修改，使用 rust_embed来读取，一般是封装好的脚本
    Builtin(String),
    // 相对路径，相对于当前执行文件，一般用于本地文件，用户可以自己编写的扩展系统脚本，可以自己修改
    Relative(String),
    // 外部脚本，非宿主程序内部的脚本，通过文件系统读取，可读可写，但是需要文件权限，一般是用户自己编写的脚本
    Absolute(String),
    // 远程http文件内容，需要网络下载
    Http(String),
    // 纯文本脚本内容，直接传递完整的脚本代码
    Text(String),
    None,
}

pub fn get_script_path(script: &ScriptFileSourceType) -> Option<&String> {
    match script {
        ScriptFileSourceType::Builtin(path) => Some(path),
        ScriptFileSourceType::Relative(path) => Some(path),
        ScriptFileSourceType::Absolute(path) => Some(path),
        ScriptFileSourceType::Http(url) => Some(url),
        ScriptFileSourceType::Text(content) => Some(content),
        _ => {None}
    }
}
