use dashmap::DashMap;
use std::fmt::{Debug, Formatter};
use serde::{Deserialize, Serialize};

#[derive(Serialize, Deserialize)]
pub struct ByteArrayMultipartFile {
    pub name: String,
    pub file_type: String,
    pub length: usize,
    pub bytes: Vec<u8>,
}

impl Default for ByteArrayMultipartFile {
    fn default() -> Self {
        ByteArrayMultipartFile {
            name: "".to_string(),
            file_type: "".to_string(),
            length: 0,
            bytes: Vec::new(),
        }
    }
}

impl Clone for ByteArrayMultipartFile {
    fn clone(&self) -> Self {
        ByteArrayMultipartFile {
            name: self.name.clone(),
            file_type: self.file_type.clone(),
            length: self.length,
            bytes: self.bytes.clone(),
        }
    }
}

impl Debug for ByteArrayMultipartFile {
    fn fmt(&self, f: &mut Formatter<'_>) -> std::fmt::Result {
        write!(
            f,
            "ByteArrayMultipartFile {{ name: {}, file_ext: {}, length: {}, bytes_mut: {} }}",
            self.name,
            self.file_type,
            self.length,
            self.bytes.len()
        )
    }
}

pub enum FileChunkReceiveStatus<T> {
    PartOk(T),
    AllOk(T),
    Err(T),
}

impl<T> FileChunkReceiveStatus<T> {
    pub fn get_value(self) -> T {
        match self {
            FileChunkReceiveStatus::PartOk(value) => value,
            FileChunkReceiveStatus::AllOk(value) => value,
            FileChunkReceiveStatus::Err(value) => value,
        }
    }
}

// 分块接收来自发送方发分块元数据信息和分块map
pub struct ByteFileChunk {
    pub file_index: usize,
    pub name: String,
    pub file_ext: String,
    pub length: usize,
    pub byte_chunk_map: DashMap<usize, Vec<u8>>, // DashMap适合高并发读写，插入无所谓顺序，插入完成之后，进行排序合并分块
}

impl ByteFileChunk {
    pub fn add_chunk(&self, index: usize, chunk: Vec<u8>) {
        self.byte_chunk_map.insert(index, chunk);
    }

    pub fn convert_byte_array_multipart_file(&self) -> ByteArrayMultipartFile {
        let mut byte_mut = Vec::with_capacity(self.length);
        // 排序并拼接所有分块
        let mut sorted_chunks: Vec<usize> = self
            .byte_chunk_map
            .iter()
            .map(|entry| *entry.key())
            .collect();
        sorted_chunks.sort_by_key(|chunk_index| *chunk_index); // 按 key (索引) 排序
        for i in sorted_chunks {
            if let Some((key, value)) = self.byte_chunk_map.remove(&i) {
                byte_mut.extend_from_slice(value.as_slice())
            }
        }
        ByteArrayMultipartFile {
            name: self.name.to_string(),
            file_type: self.file_ext.to_string(),
            length: byte_mut.len(),
            bytes: byte_mut,
        }
    }
}

impl Debug for ByteFileChunk {
    fn fmt(&self, f: &mut Formatter<'_>) -> std::fmt::Result {
        write!(
            f,
            "ByteFileChunk {{ file_index: {}, name: {}, file_ext: {}, length: {}, bytes_mut: {} }}",
            self.file_index,
            self.name,
            self.file_ext,
            self.length,
            self.byte_chunk_map.len()
        )
    }
}
