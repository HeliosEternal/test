use serde::{Deserialize, Serialize};

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct ResponseBody {
    pub code: u16,                      // 状态码，例如 200 成功，400 错误，500 服务端错误
    pub msg: Option<String>,            // 状态描述信息
    pub data: Option<ResponseBodyType>, // 返回的数据， 业务数据的结构体 对应的 json 类型
}

/// 构建一个枚举，用于各种类型数据响应的数据，在rust里使用 dyn 或者 impl  都无法解决 动态类型是None的情况，必须指定一个类型，我们在这里手动指定类型，用统一的方法序列化
#[derive(Debug, Serialize, Deserialize, Clone)]
#[serde(tag = "type", content = "content")]
pub enum ResponseBodyType {
    FileChunkAckType(FileChunkAck),
    JsonDataType(serde_json::Value),
    None,
}

impl ResponseBodyType {
    pub fn extract_file_chunk_ack(&self) -> Option<&FileChunkAck> {
        match self {
            ResponseBodyType::FileChunkAckType(file_chunk_ack) => Some(file_chunk_ack),
            _ => None,
        }
    }
    pub fn extract_json_data(self) -> Option<serde_json::Value> {
        match self {
            ResponseBodyType::JsonDataType(data) => Some(data),
            ResponseBodyType::FileChunkAckType(file_chunk_ack) => {
                Some(serde_json::to_value(file_chunk_ack).unwrap())
            }
            ResponseBodyType::None => None,
        }
    }
}

// ACK属于分块传输的一种确认机制，在某些场景下，客户端需要确认分块是否传输成功，把找个结构体放在 ResponseData 的 data承载
#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct FileChunkAck {
    pub file_index: usize,             // 确认的是哪个文件
    pub chunk_index: usize,            // 确认的分块索引
    pub is_last_chunk: bool, // 确认是否是最后一个分块  只有在下面成功是true的时候才有用，结束传输，收尾清理工作，如果是false 还需要进行重发操作
    pub success: bool,       // 确认是否成功
    pub error_message: Option<String>, // 错误信息（如果有）
}

impl FileChunkAck {
    pub fn new(
        file_index: usize,
        chunk_index: usize,
        is_last_chunk: bool,
        success: bool,
        error_message: Option<String>,
    ) -> FileChunkAck {
        FileChunkAck {
            file_index,
            chunk_index,
            is_last_chunk,
            success,
            error_message,
        }
    }

    pub fn build_ok_ack(
        file_index: usize,
        chunk_index: usize,
        is_last_chunk: bool,
    ) -> FileChunkAck {
        FileChunkAck::new(file_index, chunk_index, is_last_chunk, true, None)
    }

    pub fn build_error_ack(
        file_index: usize,
        chunk_index: usize,
        error_message: &str,
    ) -> FileChunkAck {
        FileChunkAck::new(
            file_index,
            chunk_index,
            false,
            false,
            Some(error_message.to_string()),
        )
    }
}
