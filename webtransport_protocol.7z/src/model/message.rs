use crate::model::binary_stream_file::ByteArrayMultipartFile;
use crate::model::request_payload::RequestBody;
use crate::model::response_payload::ResponseBody;
use chrono::Local;
use serde::{Deserialize, Serialize};
use std::fmt;
use strum::Display;

// 环境, 开发环境，脚本不用缓存，正式环境需要缓存，这只是一个用途，还可以扩展其他的
#[derive(Debug, Serialize, Deserialize, Clone, Display)]
pub enum Env {
    Dev,
    Prod,
}

impl Env {
    pub fn get_env() -> Env {
        let env = std::env::var("ENV").unwrap_or("dev".to_string());
        match env.as_str() {
            "dev" => Env::Dev,
            "prod" => Env::Prod,
            _ => panic!("Invalid ENV value"),
        }
    }

    pub fn is_dev(&self) -> bool {
        match self {
            Env::Dev => true,
            _ => false,
        }
    }

    pub fn is_prod(&self) -> bool {
        match self {
            Env::Prod => true,
            _ => false,
        }
    }
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct Header {
    pub env: Env,
    pub app_id: String,       // 每个小程序应用的id
    pub request_id: String,   // 当前请求的唯一ID
    pub version: u8,          // 协议版本
    pub created_date: String, // 创建请求的时间（时间戳）
    pub ext_data: Option<serde_json::Map<String, serde_json::Value>>, // 扩展header，增加一些额外的自定义数据
}

impl Header {
    // 自定义clone，实现自己需要的字段，不需要的不要复制，更加灵活
    pub fn clone_new(&self) -> Header {
        Header {
            env: self.env.clone(),
            app_id: self.app_id.clone(),
            request_id: self.request_id.clone(),
            version: self.version,
            created_date: get_milli_datetime(),
            ext_data: None,
        }
    }
}

// 请求响应枚举，只有这两种
#[derive(Debug, Serialize, Deserialize, Clone)]
#[serde(tag = "type", content = "content")]
pub enum MessageBody {
    Request(RequestBody),   // 代表消息是请求
    Response(ResponseBody), // 代表消息是响应
    None,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct WebDataMessage {
    pub header: Header,                                   // header数据
    pub url: String,                                      // 请求的路由handler
    pub body: MessageBody, // 泛型 T，用于存储请求或响应的业务数据 RequestMessage 或者 ResponseMessage   注意 如果同时包含文件流和 json请求数据，那么 json的数据在最后的一个文件的最后一个分块流再传输，避免中间重复携带
    pub file_stream: Option<Vec<ByteArrayMultipartFile>>, // 文件流数据,支持多个不同的文件
}

#[derive(Serialize, Deserialize, Clone)]
pub struct FileStreamChunkData {
    pub total_files: usize,                   // 要传输的文件总数
    pub file_index: usize,                    // 当前文件的索引，支持传输多个文件
    pub file_name: String,                    // 文件名
    pub file_type: String,                    // 文件类型
    pub file_length: usize,                   // 文件总大小
    pub total_chunk: usize,                   // 文件总分块数
    pub chunk_index: usize,                   // 当前传输的分块索引
    pub is_last_chunk: bool,                  // 是否是最后一个分块
    pub chunk_hash: String,                   // 当前分块的哈希值（例如 SHA-256 或 MD5）
    pub chunk_binary_stream: Option<Vec<u8>>, // 二进制流数据
}

// 手动实现 Debug 特性 不要打印 chunk_binary_stream，这是二进制数据 打印会很卡
impl fmt::Debug for FileStreamChunkData {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FileStreamMetadata")
            .field("total_files", &self.total_files)
            .field("file_index", &self.file_index)
            .field("name", &self.file_name)
            .field("stream_type", &self.file_type)
            .field("stream_length", &self.file_length)
            .field("chunk_total", &self.total_chunk)
            .field("chunk_index", &self.chunk_index)
            .field("is_last_chunk", &self.is_last_chunk)
            .field("chunk_hash", &self.chunk_hash)
            .field(
                "chunk_binary_stream_length",
                &self.chunk_binary_stream.as_ref().map(|v| v.len()),
            ) // 只打印长度
            .finish()
    }
}

pub fn get_milli_datetime() -> String {
    // 获取当前时间
    let now = Local::now();
    // 格式化时间，精确到毫秒
    now.format("%Y-%m-%d %H:%M:%S:%3f").to_string()
}
