use crate::init::init_log;
use dashmap::DashMap;
use log::warn;
use std::pin::Pin;
use std::sync::Arc;
use std::time::{Duration, Instant};
use tokio::sync::{Semaphore, mpsc};
use tokio_util::sync::CancellationToken;
use tracing::{error, info};

/// 任务当前的执行状态
#[derive(Clone, Debug)]
pub enum TaskStatus {
    Pending,   // 等待调度执行状态
    Running,   // 已经调度，正在执行的状态
    Completed, // 任务已经执行完成状态
    Failed,    // 用于记录任务达到最大重试次数后失败的状态
}

/// 任务的执行配置参数
#[derive(Clone)]
pub struct DelayTask {
    pub id: String,
    execute_at: Instant, // 任务何时执行
    delay: Duration,     // 每次执行后的延迟
    max_retries: usize,  // 最大重试次数
    retry_count: usize,  // 当前重试次数
    backoff_factor: f64, // 指数回退因子
    status: TaskStatus,  // 当前任务状态
    async_task: Arc<dyn Fn() -> Pin<Box<dyn Future<Output = ()> + Send>> + Send + Sync>, // 异步任务
}

impl DelayTask {
    pub fn new<F>(id: &str, delay: Duration, max_retries: usize, async_task: F) -> Self
    where
        F: Fn() -> Pin<Box<dyn Future<Output = ()> + Send>> + Send + Sync + 'static,
    {
        DelayTask {
            id: id.to_string(),
            execute_at: Instant::now() + delay,
            delay,
            max_retries,
            retry_count: 0,
            backoff_factor: 2.2,
            status: TaskStatus::Pending,
            async_task: Arc::new(async_task),
        }
    }

    pub fn new_delay_task<F>(id: &str, async_task: F) -> Self
    where
        F: Fn() -> Pin<Box<dyn Future<Output = ()> + Send>> + Send + Sync + 'static,
    {
        DelayTask {
            id: id.to_string(),
            execute_at: Instant::now(),
            delay: Duration::from_millis(300),
            max_retries: 2,
            retry_count: 0,
            backoff_factor: 1.2,
            status: TaskStatus::Pending,
            async_task: Arc::new(async_task),
        }
    }
}

pub struct ScheduleTaskManager {
    task_map: DashMap<String, DelayTask>, // 用于存储任务，如果考虑按执行时间顺序排序，可以采用BinaryHeap 更加高效，我们这里暂时不用了
    cancellation_token: CancellationToken, // 用于取消任务调度器，当任务超时最大重试次数或者任务已经结束或者需要中断放弃
    semaphore: Arc<Semaphore>, // 最大支持5个并发任务执行，太大了影响效率，如果并发流可以改大点10个
}

impl ScheduleTaskManager {
    pub fn new() -> Self {
        Self {
            task_map: DashMap::new(),
            cancellation_token: CancellationToken::new(),
            semaphore: Arc::new(Semaphore::new(5)),
        }
    }

    /// 添加任务
    pub fn add_task(&self, mut task: DelayTask) {
        if self.task_map.contains_key(&task.id) {
            info!("Task {} already exists, skipping insertion.", task.id);
            return;
        }
        task.status = TaskStatus::Pending; // 设置任务为待执行状态
        self.task_map.insert(task.id.clone(), task);
    }

    pub fn is_empty_task(&self) -> bool {
        self.task_map.is_empty()
    }

    pub fn remove_task(&self, id: &str) -> Option<DelayTask> {
        self.task_map.remove(id).map(|(_, task)| task)
    }

    /// 停止任务调度器
    pub fn stop_scheduler_task(&self) {
        self.task_map.clear();
        self.cancellation_token.cancel();
        info!("All tasks stop");
    }

    /// 启动任务调度器
    /// 任务调度器
    async fn start_scheduler(&self) {
        info!("Starting delay task scheduler...");
        loop {
            if self.is_empty_task() {
                info!("No pending tasks, stopping delay task scheduler.");
                self.stop_scheduler_task();
                return;
            }
            if self.cancellation_token.is_cancelled() {
                info!("start_scheduler cancellation_token cancel, stopping delay task scheduler.");
                return;
            }
            let now = Instant::now();

            info!("Checking for pending tasks... {}", self.task_map.len());

            let mut found_keys = vec![];
            {
                for mut entry in self.task_map.iter() {
                    let task = entry.value();
                    info!(
                        "Checking task: {}, {:?}, {},{:?}",
                        task.id,
                        task.execute_at.elapsed().as_millis(),
                        now.elapsed().as_millis(),
                        task.status
                    );
                    if task.execute_at <= now && matches!(task.status, TaskStatus::Pending) {
                        found_keys.push(task.id.clone());
                    }
                }
            }

            info!("found_keys:{}", found_keys.len());

            for key in found_keys {
                // 获取一个信号量许可，控制并发
                match self.semaphore.try_acquire() {
                    Ok(permit) => {
                        info!("Acquired permit from Semaphore.");
                        self.execute_task(key.as_str()).await;
                        drop(permit);
                    }
                    Err(error) => {
                        error!(
                            "try_acquire from Semaphore is error, skipping task execution. {}",
                            error
                        );
                    }
                }
            }

            // 动态的调度间隔
            let delay = if self.task_map.is_empty() {
                Duration::from_secs(1)
            } else {
                Duration::from_millis(50)
            };
            // 稍微休眠一段时间再继续检查
            tokio::time::sleep(delay).await;
        }
        info!("delay task scheduler stopped.");
    }

    pub async fn execute_task(&self, id: &str) {
        if self.cancellation_token.is_cancelled() {
            info!("Global failure detected, task execution stopped.");
            return;
        }
        // 判断任务是否已经达到最大重试次数，封装在独立代码块，包装获取的map的value可以及时释放
        // 如果任务已经达到最大重试次数，这里会释放value，下面才能clean这个map，不然会死锁等待
        let mut is_max_retries_reached = false;
        {
            let map = &self.task_map;
            let task_option = map.get_mut(id);
            if task_option.is_none() {
                info!("Task {} has been removed.", id);
                return;
            }

            let mut task = task_option.unwrap();

            if task.retry_count > task.max_retries {
                task.status = TaskStatus::Failed;
                println!("Task {} reached max retries and marked as Failed", task.id);
                self.stop_scheduler_task();
                return;
            }

            // 设置任务状态为 Running, 重试任务次数加一
            task.status = TaskStatus::Running;
            task.retry_count += 1;

            let async_task = task.async_task.clone();
            let task_id = task.id.clone();

            let handle = tokio::spawn(async move {
                info!("Executing task: {}", task_id);
                // 执行异步任务
                let _ = async_task().await;
                info!("Task {} completed.", task_id);
            });

            // 等待任务执行完成, 设置下一次执行计划时间
            let _ = handle.await;

            {
                info!(
                    "Task id {} ,retry_count:{}, max_retries:{}",
                    task.id, task.retry_count, task.max_retries
                );
                is_max_retries_reached = task.retry_count > task.max_retries;
                if !is_max_retries_reached {
                    // 如果任务失败且还没有达到最大重试次数，重新添加任务
                    task.status = TaskStatus::Pending;
                    task.delay =
                        Duration::from_secs_f64(task.delay.as_secs_f64() * task.backoff_factor);
                    task.execute_at = Instant::now() + task.delay;
                    //测试立即执行  mut_task.execute_at = Instant::now();
                }
            }
        }
        // 超过最大重试次数，任务失败
        if is_max_retries_reached {
            info!("Task  has failed after reaching max retries.");
            self.stop_scheduler_task();
        }
    }
}

#[tokio::test]
pub async fn test_retry_task() {
    init_log();
    let scheduler = ScheduleTaskManager::new();
    scheduler.add_task(DelayTask::new_delay_task("100", || {
        Box::pin(async move {
            tokio::time::sleep(Duration::from_secs(1)).await;
            info!("task 100");
        })
    }));
    scheduler.add_task(DelayTask::new_delay_task("101", || {
        Box::pin(async move {
            tokio::time::sleep(Duration::from_secs(2)).await;
            info!("task 101");
        })
    }));

    scheduler.add_task(DelayTask::new_delay_task("102", || {
        Box::pin(async move {
            tokio::time::sleep(Duration::from_millis(490)).await;
            info!("task 102");
        })
    }));

    scheduler.add_task(DelayTask::new_delay_task("103", || {
        Box::pin(async move {
            tokio::time::sleep(Duration::from_millis(600)).await;
            info!("task 103");
        })
    }));
    scheduler.start_scheduler().await;
}
