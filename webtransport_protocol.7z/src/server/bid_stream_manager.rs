use anyhow::anyhow;
use crossbeam::queue::SegQueue;
use dashmap::DashMap;
use idgenerator::IdInstance;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use std::time::Duration;
use tokio::sync::{mpsc, oneshot};
use tracing::{error, info};
use wtransport::{Connection, RecvStream, SendStream, VarInt};
use crate::protocol::length_coder::LengthDecoder;

/// 全局存储客户端连接id和双向流池
lazy_static::lazy_static! {
    static ref CONNECTION_BID_STREAM_MAP: DashMap<i64, BidStreamPool> = DashMap::new();
}

/// 发送流封装，使用 Sender 替代 Mutex<SendStream>
pub struct WtpSendStream {
    pub id: i64,
    pub sender: mpsc::Sender<(
        Vec<u8>,
        oneshot::Sender<Result<(), wtransport::error::StreamWriteError>>,
    )>,
    pub active: Arc<AtomicBool>, // 健康状态
}

pub struct BidStreamPool {
    pub connection_id: i64,
    pub connection: Connection,
    pub stream_map: DashMap<i64, Arc<WtpSendStream>>, // 流映射
    pub stream_queue: SegQueue<Arc<WtpSendStream>>,   // 轮询队列
    pub idle_timeout: Duration,                       // 空闲超时
    pub min_available_streams: usize,                 // 最小可用流阈值
    pub max_streams: usize,                           // 最大流数量
}

impl BidStreamPool {
    pub fn new(connection_id: i64, connection: Connection) -> Self {
        Self {
            connection_id,
            connection,
            stream_map: DashMap::new(),
            stream_queue: SegQueue::new(),
            idle_timeout: Duration::from_secs(300),
            min_available_streams: 5,
            max_streams: 100,
        }
    }

    /// 删除无效流
    pub fn remove_stream(&self, stream_id: i64) {
        if let Some((_, stream)) = self.stream_map.remove(&stream_id) {
            stream.active.store(false, Ordering::SeqCst); // 标记为无效
                                                          // Sender 关闭时，异步任务会自动退出，无需显式关闭
        }
    }

    /// 获取下一个可用流
    pub async fn next_stream(&self) -> Option<Arc<WtpSendStream>> {
        while let Some(stream) = self.stream_queue.pop() {
            if stream.active.load(Ordering::SeqCst) {
                return Some(stream);
            }
        }
        None
    }

    /// 新增流并启动异步任务
    fn push_stream(&self, stream_id: i64, send_stream: SendStream) {
        let (tx, mut rx) = mpsc::channel::<(
            Vec<u8>,
            oneshot::Sender<Result<(), wtransport::error::StreamWriteError>>,
        )>(100);
        let (exit_tx, exit_rx) = oneshot::channel();
        let active = Arc::new(AtomicBool::new(true));
        let arc_wtp_stream = Arc::new(WtpSendStream {
            id: stream_id,
            sender: tx.clone(),
            active: active.clone(),
        });

        let connection_id = self.connection_id;
        // 异步任务处理发送，通过监听数据二进制流实现发送，send_stream避免使用互斥锁每次获取可变引用，直接在监听消息里发送，提升性能
        tokio::spawn(async move {
            let mut send_stream = send_stream;
            while let Some((buf, result_tx)) = rx.recv().await {
                let result = send_stream.write_all(&buf).await;
                if result.is_err() {
                    let _ = result_tx.send(result); // 返回发送结果
                    break; // 发送失败，退出任务
                }
                let _ = result_tx.send(Ok(())); // 返回发送结果
            }
            let _ = exit_tx.send((stream_id, connection_id)); // 通知任务退出
        });

        // 监听任务退出
        tokio::spawn(async move {
            if let Ok((stream_id, connection_id)) = exit_rx.await {
                info!(
                    "Stream  exit, connection_id {}, stream_id {}",
                    connection_id, stream_id
                );
                remove_stream(connection_id, stream_id);
            }
        });

        self.stream_map.insert(stream_id, arc_wtp_stream.clone());
        self.stream_queue.push(arc_wtp_stream);
    }

    /// 检查流池是否为空
    pub async fn is_empty(&self) -> bool {
        self.stream_map.is_empty() && self.stream_queue.is_empty()
    }

    /// 发送消息并动态管理流
    pub async fn send_message(&self, buf: &[u8]) -> anyhow::Result<()> {
        let max_attempts = 5;
        let mut attempts = 0;

        while attempts < max_attempts {
            match self.next_stream().await {
                Some(stream) => {
                    let (result_tx, result_rx) = oneshot::channel();
                    let send_result = stream.sender.send((buf.to_vec(), result_tx)).await;

                    if send_result.is_err() {
                        tracing::error!("Stream {} sender closed", stream.id);
                        self.remove_stream(stream.id);
                        attempts += 1;
                        continue;
                    }

                    match result_rx.await {
                        Ok(_) => {
                            self.stream_queue.push(stream); // 发送成功，归还队列
                            return Ok(());
                        }
                        Err(e) => {
                            tracing::error!("Stream {} failed: {:?}", stream.id, e);
                            self.remove_stream(stream.id); // 发送失败，移除
                        }
                    }
                }
                None => {
                    if self.is_empty().await {
                        tracing::info!(
                            "Stream pool empty, opening new stream for connection {}",
                            self.connection_id
                        );
                        open_new_bid_stream(self.connection_id).await?;
                    } else {
                        tokio::time::sleep(Duration::from_millis(10)).await;
                    }
                }
            }
            attempts += 1;
        }
        Err(anyhow!("Failed to send after {} attempts", max_attempts))
    }
}

/// 外部移除流函数
pub fn remove_stream(connection_id: i64, stream_id: i64) {
    if let Some(pool) = CONNECTION_BID_STREAM_MAP.get(&connection_id) {
        pool.remove_stream(stream_id);
    }
}

/// 创建新双向流
pub async fn open_new_bid_stream(connection_id: i64) -> anyhow::Result<()> {
    let connection_option = CONNECTION_BID_STREAM_MAP
        .get(&connection_id)
        .ok_or_else(|| anyhow!("Connection not found: {}", connection_id))?;
    let bid_stream_pool = connection_option.value();
    let bi_stream = bid_stream_pool.connection.open_bi().await?.await?;
    let send_stream = bi_stream.0;
    let recv_stream = bi_stream.1;
    let stream_id = IdInstance::next_id();
    bid_stream_pool.push_stream(stream_id, send_stream);
    listener_bi_stream_message(connection_id, stream_id, recv_stream); // 监听接收流
    Ok(())
}

/// 监听接收流消息（未改动，仅为完整性保留）
pub fn listener_bi_stream_message(connection_id: i64, stream_id: i64, mut recv_stream: RecvStream) {
    let mut buffer = vec![0; 65536].into_boxed_slice();
    tokio::spawn(async move {
        let pool = CONNECTION_BID_STREAM_MAP.get(&connection_id).unwrap();
        let pool = pool.value();
        let idle_timeout = pool.idle_timeout;
        let mut last_active = std::time::Instant::now();

        let mut decoder = LengthDecoder::new(1024 * 1024 * 10);
        loop {
            match recv_stream.read(&mut buffer).await {
                Ok(Some(read_size)) => {
                    tracing::info!("Received {} bytes from stream {}", read_size, stream_id);
                    last_active = std::time::Instant::now();
                    decoder.feed(&buffer[..read_size]);
                    match decoder.decode() {
                        Ok(messages) => {
                            for message in messages {
                                tracing::info!("Received message from stream {}", stream_id);
                            }
                        }
                        Err(e) => {
                            tracing::error!("Decode error: {:?}", e);
                        }
                    }
                }
                Ok(None) => {
                    tracing::info!("Stream {} closed by peer", stream_id);
                    break;
                }
                Err(e) => {
                    tracing::error!("Stream {} read error: {:?}", stream_id, e);
                    break;
                }
            }

            if pool.stream_map.len() < pool.min_available_streams
                && last_active.elapsed() > idle_timeout
            {
                recv_stream.stop(VarInt::from_u32(409));
                tracing::info!("Stream {} idle timeout, closing", stream_id);
                break;
            }
            tokio::time::sleep(Duration::from_millis(10)).await;
        }

        if let Some(pool) = CONNECTION_BID_STREAM_MAP.get(&connection_id) {
            pool.remove_stream(stream_id);
        }
    });
}

/// 初始化流池
pub async fn init_bid_stream(connection_id: i64, connection: Connection) {
    let bid_stream_pool = BidStreamPool::new(connection_id, connection);
    CONNECTION_BID_STREAM_MAP.insert(connection_id, bid_stream_pool);
    for _ in 0..10 {
        let _ = open_new_bid_stream(connection_id).await;
    }
}

/// 外部发送消息接口
pub async fn send_message(connection_id: &i64, buf: &[u8]) -> anyhow::Result<()> {
    let connection_option = CONNECTION_BID_STREAM_MAP
        .get(connection_id)
        .ok_or_else(|| anyhow!("Connection not found: {}", connection_id))?;
    connection_option.send_message(buf).await
}
