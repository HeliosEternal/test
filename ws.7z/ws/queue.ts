const MESSAGE_LENGTH_SIZE = 4; // 消息头的长度（4 字节，表示消息大小）

export class CircularQueue {
    private buffer: SharedArrayBuffer;
    private view: DataView;
    private queueSize: number;
    private dataOffset: number; // 数据区域起始偏移量
    private writeIndex: Int32Array; // 写指针
    private readIndex: Int32Array;  // 读指针

    constructor(sharedBuffer: SharedArrayBuffer) {
        let bufferSize = sharedBuffer.byteLength;
        if (bufferSize & (bufferSize - 1)) {
            throw new Error("bufferSize must be a power of 2 for optimized modulo operation.");
        }

        // 初始化缓冲区
        this.buffer = sharedBuffer;
        this.view = new DataView(this.buffer);
        this.queueSize = bufferSize;

        // 使用独立的 Int32Array 存储读写指针
        //this.writeIndex = new Int32Array(new SharedArrayBuffer(4)); // 写指针
        // this.readIndex = new Int32Array(new SharedArrayBuffer(4)); // 读指针

        this.writeIndex = new Int32Array(this.buffer, 0, 1);
        this.readIndex = new Int32Array(this.buffer, 4, 1);

        // 数据区域起始偏移量,前面占据了两个读写指针的空间8个字节
        this.dataOffset = 8;

        // 初始化读写指针
        Atomics.store(this.writeIndex, 0, 0);
        Atomics.store(this.readIndex, 0, 0);
    }


    // 写入消息
    public write(message: string): boolean {
        //const messageStr = JSON.stringify(message);
        const messageStr = message;
        const messageSize = messageStr.length;
        const totalSize = MESSAGE_LENGTH_SIZE + messageSize; // 消息头大小 + 消息内容大小

        const writePtr = Atomics.load(this.writeIndex, 0);
        const readPtr = Atomics.load(this.readIndex, 0);

        // 计算可用空间
        const availableSpace = (readPtr - writePtr - 1 + this.queueSize) & (this.queueSize - 1);

        if (availableSpace < totalSize) {
            return false; // 空间不足，写入失败
        }

        // 判断是否需要环绕（提前检查总大小是否超出缓冲区尾部）
        let actualWritePos = writePtr + this.dataOffset;
        if (actualWritePos + totalSize > this.queueSize) {
            // 如果写入位置超出缓冲区，直接环绕到起始位置
            actualWritePos = this.dataOffset;
        }


        const encoder = new TextEncoder();
        const messageData = encoder.encode(messageStr);

        // 写入消息头（4 字节，小端序）
        this.view.setInt32(actualWritePos, messageSize, true);

        // 写入消息内容
        const payloadOffset = actualWritePos + MESSAGE_LENGTH_SIZE; // 消息内容起始位置
        const messageArray = new Uint8Array(this.buffer, payloadOffset, messageSize);
        messageArray.set(messageData);

        // 更新写指针（直接基于 `actualWritePos` 递增）
        const newWriteIndex = actualWritePos + totalSize;
        Atomics.store(this.writeIndex, 0, newWriteIndex);

        return true; // 写入成功
    }


    // 读取消息
    public read(): any | null {
        const MESSAGE_LENGTH_SIZE = 4; // 消息头的长度（4 字节，表示消息大小）

        const writePtr = Atomics.load(this.writeIndex, 0);
        const readPtr = Atomics.load(this.readIndex, 0);

        // 检查是否有数据可读
        if (readPtr === writePtr) {
            return null; // 队列为空
        }

        // 计算当前的读取位置
        let actualReadPos = readPtr + this.dataOffset;

        // 如果读取位置超出缓冲区大小，直接环绕到起始位置
        if (actualReadPos >= this.buffer.byteLength) {
            actualReadPos = this.dataOffset;
        }

        // 读取消息头（获取消息体大小）
        const messageSize = this.view.getInt32(actualReadPos, true);
        const totalSize = MESSAGE_LENGTH_SIZE + messageSize;

        // 判断消息是否完整（当前空间是否足够容纳这条消息）
        if (actualReadPos + totalSize > this.buffer.byteLength) {
            // 如果当前剩余空间不足，直接环绕到起始位置并重新读取消息头
            actualReadPos = this.dataOffset;
        }


        //消息内容的起始位置
        const payloadOffset = actualReadPos + MESSAGE_LENGTH_SIZE;

        const messageData = new Uint8Array(this.buffer, payloadOffset, messageSize);

        const copiedData = new Uint8Array(messageData.length);
        copiedData.set(messageData);


        // 解码消息内容
        const decoder = new TextDecoder();
        const messageStr = decoder.decode(copiedData);

        // 更新读指针（直接基于当前 `readPtr` 增量更新）
        const newReadIndex = actualReadPos + totalSize; // 新的读取位置（无需取模）

        Atomics.store(this.readIndex, 0, newReadIndex);
        return JSON.parse(messageStr); // 返回解码后的消息
    }

}
