import {
    RequestBodyBuilder,
    ScriptFileSourceType,
    ScriptFileSourceTypeBuilder,
    ScriptFunctionTask
} from "../model/request.ts";
import {Header, MessageBodyBuilder, WSMessage} from "../model/ws-message.ts";
import {WebSocketManager} from "./main..ts";


const webSocketManager: WebSocketManager = new WebSocketManager(5, "ws://localhost:3030/ws")


export function callBuiltinScript(file_name: string, function_name: string, function_param: Object) {
    let script_file_source_type = ScriptFileSourceTypeBuilder.builtin(file_name)
    return callScript(script_file_source_type, function_name, function_param);
}

function callScript(script_file_source_type: ScriptFileSourceType, function_name: string, function_param: Object) {
    let header = new Header("com.miniapp");
    let script_function_task = new ScriptFunctionTask(script_file_source_type, function_name, function_param);
    let requestBody = RequestBodyBuilder.CallScript(script_function_task);
    let messageBody = MessageBodyBuilder.Request(requestBody);
    let wsMessage = new WSMessage(header, "/call-script", messageBody);
    callLuaScript(wsMessage);
}

function callLuaScript(wsMessage: WSMessage) {
    webSocketManager.addMessageToBuffer(wsMessage);
}




