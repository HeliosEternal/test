// 消息类型定义
export interface Message {
    id: number;
    payload: any;
}

// Worker状态
export interface WorkerStatus {
    requestQueueSize: number;
    responseQueueSize: number;
    isProcessing: boolean;
}

// 共享内存布局
export enum SharedBufferOffset {
    REQUEST_READ_PTR = 0,
    REQUEST_WRITE_PTR = 4,
    RESPONSE_READ_PTR = 8,
    RESPONSE_WRITE_PTR = 12,NEW_MESSAGE_FLAG = 16,
    QUEUE_DATA_START = 20
}
