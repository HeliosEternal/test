import {CircularQueue} from "./queue";

export class WebSocketManager {
    private workers: Worker[] = [];
    private requestQueues: CircularQueue[] = [];
    private responseQueues: CircularQueue[] = [];
    private eventQueue: Set<number> = new Set(); // 事件队列：记录有消息的队列索引
    private pollInterval: number = 5; // 定时轮询间隔(ms)
    private currentWorkerIndex: number = 0;


    private messageBuffer: any[] = [];
    private isSending: boolean = false;

    constructor(workerCount: number, wsUrl: string) {
        this.initializeWorkers(workerCount, wsUrl);
        this.startEventQueueProcessing();
        this.startPolling();
    }

    private initializeWorkers(workerCount: number, wsUrl: string) {
        for (let i = 0; i < workerCount; i++) {
            const requestBuffer = new SharedArrayBuffer(1024 * 1024 * 16); // 1MB 请求队列
            const responseBuffer = new SharedArrayBuffer(1024 * 1024 * 16); // 1MB 响应队列

            const requestQueue = new CircularQueue(requestBuffer);
            const responseQueue = new CircularQueue(responseBuffer);

            // const worker = new Worker(new URL("./socket-worker.ts", import.meta.url));
            const worker = new Worker(new URL("./socket-worker.ts", import.meta.url), {
                type: "module",
            });
            worker.postMessage({wsUrl, requestBuffer, responseBuffer, queueIndex: i});

            // 监听 Worker 通知
            worker.onmessage = (event) => {
                if (event.data.type === "NOTIFY") {
                    this.eventQueue.add(event.data.queueIndex);
                }
            };

            this.workers.push(worker);
            this.requestQueues.push(requestQueue);
            this.responseQueues.push(responseQueue);
        }
    }

    // 向缓冲队列中添加消息
    public addMessageToBuffer(message: any): void {
        this.messageBuffer.push(message);
        if (!this.isSending) {
            this.processMessageBuffer();
        }
    }

    // 处理缓冲队列中的消息
    private async processMessageBuffer(): Promise<void> {
        this.isSending = true;

        while (this.messageBuffer.length > 0) {
            const message = this.messageBuffer.shift();
            const success = this.send(message);

            if (!success) {
                console.warn("Message send failed, retrying...", message);
                this.messageBuffer.unshift(message); // 将消息放回缓冲队列
                await new Promise((resolve) => setTimeout(resolve, 5)); // 延迟 10ms 再次尝试
            }
        }

        this.isSending = false;
    }


    // 发送消息到 Worker
    public send(message: any): boolean {
        let attempts = 0;

        while (attempts < this.workers.length) {
            // 获取当前队列索引
            const queueIndex = (this.currentWorkerIndex + attempts) % this.workers.length;
            const queue = this.requestQueues[queueIndex];

            // 尝试写入消息
            if (queue.write(JSON.stringify(message))) {
                // 写入成功后，更新轮询索引并返回成功
                this.currentWorkerIndex = (queueIndex + 1) % this.workers.length;
                return true;
            }

            // 写入失败，立即切换到下一个队列
            attempts++;
        }

        // 如果所有队列都满了，返回失败
        console.warn("All worker request queues are full, message dropped");
        return false;
    }


    private startEventQueueProcessing() {
        let index = 0;
        let startTime = 0;
        const processEvents = () => {
            if (this.eventQueue.size > 0) {
                // 批量处理通知的队列
                const notifiedQueues = Array.from(this.eventQueue);
                this.eventQueue.clear();

                for (const queueIndex of notifiedQueues) {
                    const queue = this.responseQueues[queueIndex];
                    let response;
                    while ((response = queue.read()) !== null) {
                        index++;
                        if (index == 1) {
                            startTime = performance.now();
                        } else if (index == 1000) {
                            let endTime = performance.now();
                            console.log(`1000 条消息接收耗时：${endTime - startTime} 毫秒`);
                            startTime = 0;
                            index = 0;
                        }
                        console.log("startEventQueueProcessing Processed response from queue", queueIndex, response);
                    }
                }
            }
            setTimeout(processEvents, 50); // 每 10ms 检查一次
        };
        processEvents();
    }

    private startPolling() {
        let index = 0;
        let startTime = 0;
        const poll = () => {
            for (let i = 0; i < this.responseQueues.length; i++) {
                const queue = this.responseQueues[i];
                if (!this.eventQueue.has(i)) {
                    let response;
                    while ((response = queue.read()) !== null) {
                        console.log("startPolling Polled response from queue", i, response);
                        index++;
                        if (index == 1) {
                            startTime = performance.now();
                        } else if (index == 3000) {
                            let endTime = performance.now();
                            console.log(`3000 条消息接收耗时：${endTime - startTime} 毫秒`);
                            startTime = 0;
                            index = 0;
                        }
                        console.log("startPolling index queue", index);
                    }


                }
            }

            setTimeout(poll, this.pollInterval); // 定时轮询
        };

        poll();
    }
}

