
use std::error::Error;
use bytes::Bytes;
use fastwebsockets::{FragmentCollector, Frame, OpCode, Payload, upgrade, WebSocketError};
use hyper::{Request, Response};
use hyper::server::conn::http1;
use hyper::service::service_fn;
use hyper::upgrade::Upgraded;
use hyper_util::rt::TokioIo;
use http_body_util::Empty;
use log::{error, info};
use tokio::{io, select};
use tokio::sync::mpsc;
use tokio::sync::mpsc::Sender;
use crate::websocket::model::websocket_message::WSMessage;
use crate::websocket::client_sender_manager::GLOBAL_CLIENT_SENDER_MANAGER;
use crate::websocket::error::eq_websocket_close_error;


pub async fn start_websocket_service() -> io::Result<()> {
      let listener = tokio::net::TcpListener::bind("127.0.0.1:8080").await?;
      println!("Server started, listening on {}", "127.0.0.1:8080");
      // 循环获取客户端连接事件，这个循环是阻塞的
      loop {
            let (stream, _) = listener.accept().await?;
            let addr = stream.peer_addr().unwrap().to_string();
            println!("Client connected ip addr: {}", addr);
            // 处理客户端连接请求
            tokio::spawn(async move {
                  let builder = http1::Builder::new();
                  let io = hyper_util::rt::TokioIo::new(stream);
                  let conn_fut = builder.serve_connection(io, service_fn(server_upgrade)).with_upgrades();
                  if let Err(e) = &conn_fut.await {
                        println!("An error occurred: {:?}", e);
                      }
                });
          }
}




async fn server_upgrade<T>(mut req: Request<T>) -> Result<Response<Empty<Bytes>>, WebSocketError> {
      // 对request对象进行升级websocket
      let (response, fut) = upgrade::upgrade(&mut req)?;
      // 这个地方继续开启异步任务去处理流的相关操作
      tokio::task::spawn(async move {
            // unconstrained代表一个不受tokio运行时限制的异步任务，tokio默认有最大线程数和最大等待时间，而这个方法不受这个限制
            // 请确保处理不太耗时和资源的操作
            if let Err(e) = tokio::task::unconstrained(handle_client(fut)).await {
                  eprintln!("Error in websocket connection: {:?}", e);
                }
            println!("客户端结束了...");
          });
      // let response = Response::new("hello world");
      // let response = Response::builder().status(200).body(Body::from("hello world")).unwrap();
      // 升级完成立即返回，注意这里返回之后，上面的异步任务还在继续执行
      Ok(response)
}




async fn handle_client(fut: upgrade::UpgradeFut) -> Result<(), WebSocketError> {
      // 最大消息默认64MB
      let websocket = fut.await?;
      let mut ws = FragmentCollector::new(websocket);
      /// 一个客户端一个通道，用于客户端内收发消息
      let (sender, mut receiver) = mpsc::channel(5000);


      let mut app_id = None;
      // 使用 tokio::select! 同时处理接收客户端消息和发送消息
      loop {
            // 如果需要关闭客户端连接，再加一个分支 监听关闭消息，直接break 就可以中断select!循环，然后客户端就会被关闭，因为不会被阻塞了，
            // 所有权move之后就会关闭
            select! {
      // 读取客户端发送的消息
      result = ws.read_frame()=> {
        match result{
          Ok(mut frame) => {
            // 如果客户端主动关闭，我们这里也要做相应的关闭释放资源动作
            let result = decode_received_frame(&mut frame);
            if let Err(error) = &result{
              error!("Error handling received frame: {:?}", &error);
              // 如果客户端发送关闭消息，最好在这里可以捕获特定的关系消息类型，然后 break 断开连接
              if eq_websocket_close_error(error){
                 break;
              }
             }
            let ws_messae = result.unwrap();
            let app_id_str = create_app_sender(sender.clone(), &ws_messae);
            app_id =Some(app_id_str);
            // 分配到统一的handler处理器中，并且自动完成序列化，上下文的创建赋值操作
            dispatch_handler(ws_messae).await;


          }
          Err(error) => {
             error!("ws read_frame error : {:?}", &error);
             // 如果客户端发送关闭消息，最好在这里可以捕获特定的关系消息类型，然后 break 断开连接
              if eq_websocket_close_error(&error) {
                 break;
              }
             break;
          }
        }
      },
      // 接收其他任务推送来的消息，准备发送给客户端的消息，用上面的wrap_sender就可以发送，在这里接收到
      Some(value) = receiver.recv() => {
        if let Err(e) = send_response(&mut ws, value).await {
          eprintln!("Error sending response: {:?}", e);
        }
      },
    }
          }


      if let Some(app_id) = app_id {
            GLOBAL_CLIENT_SENDER_MANAGER.remove_client_sender(app_id.as_str());
          }
      println!("客户端连接断开啦,移除map中的通道");
      Ok(())
}


fn decode_received_frame(frame: &mut Frame<'_>) -> Result<WSMessage, WebSocketError> {
      match frame.opcode {
            OpCode::Close => {
                  info!("Client closed ");
                  Err(WebSocketError::ConnectionClosed)
                }
            OpCode::Text => {
                  let result = utf8::decode(&frame.payload).unwrap();
                  /// 不支持Text 性能太差了
                  info!("receive text message {}", result);
                  Err(WebSocketError::InvalidFragment)
                }
            OpCode::Binary => {
                  let binary_data = frame.payload.to_mut();
                  let ws_message_result: Result<WSMessage, rmp_serde::decode::Error> = rmp_serde::from_slice(binary_data);
                  if ws_message_result.is_err() {
                        return Err(WebSocketError::InvalidFragment);
                      }
                  Ok(ws_message_result.unwrap())
                }
            _ => Err(WebSocketError::InvalidFragment),
          }
}


pub fn create_app_sender(sender: Sender<WSMessage>, ws_message: &WSMessage) -> String {
      let app_id = &ws_message.header.app_id;
      GLOBAL_CLIENT_SENDER_MANAGER.add_client_sender(app_id.as_str(), sender.clone());
      app_id.as_str().to_string()
}


pub async fn dispatch_handler(ws_message: WSMessage){
     println!("dispatch_handler: {}",&ws_message);


}


async fn send_response(ws: &mut FragmentCollector<TokioIo<Upgraded>>, value: WSMessage) -> Result<(), WebSocketError> {
      let response_payload = rmp_serde::encode::to_vec(&value).unwrap();
      let payload = Payload::from(response_payload);
      let frame = Frame::binary(payload);
      ws.write_frame(frame).await
}
