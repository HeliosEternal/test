use dashmap::DashMap;
use serde::de::DeserializeOwned;
use serde::Deserializer;
use crate::websocket::model::websocket_message::{MessageBody, WSMessage};
use crate::websocket::model::WSContext;

type Handler<WSMessage, WSContext> = Box<dyn Fn(WSMessage, WSContext) -> WSMessage + Send + Sync>;


struct Router {
    handlers: DashMap<String, Handler<WSMessage, WSContext>>,
}

impl Router {
    pub fn new() -> Self {
        Router {
            handlers: DashMap::new(),
        }
    }

    /// 注册 handler
    pub fn register_handler<T>(&self, url: String, handler: impl Fn(T, WSContext) -> WSMessage + 'static + Send + Sync)
    where
        T: DeserializeOwned + Send + Sync + 'static,
    {
        let boxed_handler = Box::new(move |data: WSMessage, ctx: WSContext| -> WSMessage {
            let data = match data.body {
                MessageBody::Request(request) => {
                    let business_value_option = request.body.data;
                    if business_value_option.is_some() {
                        let value = business_value_option.unwrap();
                        let request: T = serde_json::from_str(value.to_string().as_str());
                        return request;
                    }


                    let json_data = serde_json::to_string(&request.body.data).unwrap();
                }
                MessageBody::Response(response) => {
                    let json_data = serde_json::to_string(&response.body).unwrap();
                }
            };

            handler(ctx, data)
        });


        let boxed_handler = Box::new(move |business_struct: T, ctx: WSContext| -> WSMessage {
            let request: T = serde_json::from_str(&json_data)

            handler(business_struct, ctx)
        });
        self.handlers.insert(url, boxed_handler);
    }

    pub fn route(&self, ws_message: WSMessage) {
        let user_context = WSContext {
            app_id: "com.mini.app".to_string(),
            user_id: "100".to_string(),
            session_id: "12121sa2s12a".to_string(),
        };

        let mut url = "";
        match &ws_message.body {
            MessageBody::Request(req) => {
                println!("Processing request: {:?}", req);
                // 这里你可以使用 req（RequestMessage 实例）
                url = &req.request_type.to_string();
            }
            MessageBody::Response(res) => {
                println!("Processing response: {:?}", res);
                // 这里你可以使用 res（ResponseMessage 实例）
                url = &res.response_type.to_string();
            }
        }

        if let Some(handler) = self.handlers.get(url) {
            let handler = handler.value();
            handler(ws_message, user_context);
        } else {
            println!("No handler found for message type: {:?}", message.message_type);
        }
    }
}
