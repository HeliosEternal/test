use serde::{Deserialize, Serialize};


#[derive(Debug, Serialize, Deserialize)]
pub struct RequestMessage {
    pub request_type: RequestType, // 请求类型，用于区分业务场景
    pub body: RequestBody, // 请求体，存放具体的请求数据
}


#[derive(Debug, Serialize, Deserialize)]
pub struct RequestBody {
    pub data: Option<serde_json::Value>, // 承载业务的json数据 对应一个handler控制处理器, 在业务数据+二进制流中，只有第一次会传输，后面是None，只是传输 header+元数据+二进制流
    pub meta_data: Option<Metadata>, // 二进制分块传输的元数据信息
    pub binary_stream: Option<Vec<u8>>, // 二进制流字段 Vec<u8>可以支持json序列化成数组，也支持 messagepack协议序列化，比较友好，如我们要操作字节可以使用 BytesMut
}


#[derive(Debug, Serialize, Deserialize)]
pub struct Metadata {
    pub name: String,    // 文件名
    pub stream_type: String, // 文件类型
    pub stream_length: u64, // 文件总大小
    pub chunk_total: u32,  // 文件总分块数
    pub chunk_index: u32,  // 当前传输的分块索引
    pub is_last_chunk: bool, // 是否是最后一个分块
    pub file_index: u32,  // 当前文件的索引，支持传输多个文件
    pub total_files: u32,  // 要传输的文件总数
    pub chunk_hash: String, // 当前分块的哈希值（例如 SHA-256 或 MD5）
}


#[derive(Debug, Serialize, Deserialize, PartialEq, Eq, Hash, Clone)]
pub enum RequestType {
    CallLuaScript,
    FileUpload,
    ScriptRun,
    // 添加更多的请求类型
    Other, // 用于扩展
}


#[derive(Debug, Serialize, Deserialize)]
pub struct ScriptFunctionTask {
    /// lua 文件的相对路径
    pub lua_file_path: String,
    /// 需要调用的lua函数名称
    pub function_name: String,
    /// 函数参数，json数据，数组形式，支持多个参数
    pub function_param: serde_json::Value,
}




