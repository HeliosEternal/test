use serde::{Deserialize, Serialize};
use crate::websocket::model::request_payload::RequestMessage;
use crate::websocket::model::response_payload::ResponseMessage;


/// 由于websocket是一个全双工协议，所以需要一个消息结构体来封装请求和响应， A作为客户端 既可以对 B 服务端发送请求消息，也可以对B进行发送响应消息，反之B亦然
// 通用的消息结构体
#[derive(Debug, Serialize, Deserialize)]
pub struct WSMessage {
    //pub request_response_enum: RequestResponse,  // 区分是请求还是响应
    pub header: Header,   // 通用的元数据
    pub body: MessageBody,   // 泛型 T，用于存储请求或响应的业务数据 RequestMessage 或者 ResponseMessage
}


#[derive(Debug, Serialize, Deserialize)]
#[serde(tag = "type", content = "content")]
pub enum MessageBody {
    Request(RequestMessage), // 代表消息是请求
    Response(ResponseMessage), // 代表消息是响应
}


#[derive(Debug, Serialize, Deserialize)]
pub struct Header {
    pub app_id: String, // 每个小程序应用的id
    pub package_id: String, // 当前数据包的唯一ID
    pub version: u8, // 协议版本
    pub created_date: f64, // 创建请求的时间（时间戳）
}


// 请求响应枚举，只有这两种
#[derive(Debug, PartialEq, Eq, Hash, Clone)]
pub enum RequestResponse {
    Request, // 代表消息是请求
    Response, // 代表消息是响应
}


