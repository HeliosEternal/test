
use serde::{Deserialize, Serialize};




#[derive(Debug, Serialize, Deserialize)]
pub struct ResponseMessage {
    pub response_type: ResponseType, // 响应类型，用于区分业务场景
    pub body: ResponseBody, // 响应体，存放具体的响应数据
}




#[derive(Debug, Serialize, Deserialize)]
pub struct ResponseBody {
    pub code: u16,       // 状态码，例如 200 成功，400 错误，500 服务端错误
    pub msg: String,      // 状态描述信息
    pub data: Option<serde_json::Value>,    // 返回的数据， 业务数据的结构体 对应的 json 类型
}




// ACK属于分块传输的一种确认机制，在某些场景下，客户端需要确认分块是否传输成功，把找个结构体放在 ResponseData 的 data承载
#[derive(Debug, Serialize, Deserialize)]
pub struct Ack {
    pub chunk_index: u32,   // 确认的分块索引
    pub file_index: u32,   // 确认的是哪个文件
    pub success: bool,    // 确认是否成功
    pub error_message: Option<String>, // 错误信息（如果有）
}




#[derive(Debug, Serialize, Deserialize,PartialEq, Eq, Hash, Clone)]
pub enum ResponseType {
    UploadAck,    // 文件上传确认
    ScriptResult,  // 脚本执行结果
    Error(String),  // 错误响应
    PartialSuccess, // 部分成功
    Success,     // 完全成功
    // 添加更多的响应类型
    Other(String),  // 用于扩展
}