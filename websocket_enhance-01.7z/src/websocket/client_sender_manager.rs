use std::sync::Arc;
use dashmap::DashMap;
use tokio::sync::mpsc;
use lazy_static::lazy_static;
use crate::websocket::model::websocket_message::WSMessage;


lazy_static::lazy_static! {
 pub static ref GLOBAL_CLIENT_SENDER_MANAGER: ClientSenderManager= {
 ClientSenderManager::new()
 };
}


pub fn get_client_sender_manager() -> &'static GLOBAL_CLIENT_SENDER_MANAGER {
      return &GLOBAL_CLIENT_SENDER_MANAGER;
}




pub struct ClientSenderManager {
      pub client_sender_map: DashMap<String, mpsc::Sender<WSMessage>>,
}


impl ClientSenderManager {
      pub fn new() -> ClientSenderManager {
            ClientSenderManager {
                  client_sender_map: DashMap::new(),
                }
          }


      pub fn add_client_sender(&self, app_id: &str, sender: mpsc::Sender<WSMessage>) {
            self.client_sender_map.insert(app_id.to_string(), sender);
          }


      pub fn get_client_sender(&self, app_id: &str) -> Option<mpsc::Sender<WSMessage>> {
            self.client_sender_map.get(app_id).map(|entry| entry.value().clone())
          }


      pub fn send_response(&self, app_id: &str, response_data: WSMessage) {
            if let Some(sender) = self.get_client_sender(app_id) {
                  sender.try_send(response_data).unwrap()
                }
          }
      pub fn remove_client_sender(&self, app_id: &str) {
            self.client_sender_map.remove(app_id);
          }
}
