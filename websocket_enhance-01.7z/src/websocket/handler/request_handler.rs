use crate::websocket::model::response_payload::ResponseMessage;
use crate::websocket::model::websocket_message::WSMessage;
use crate::websocket::model::WSContext;



/// 一个通用的 handler trait，用于处理业务逻辑
pub trait WSHandler {
    fn handle(&self, ws_message: WSMessage, ctx: WSContext) -> WSMessage;
}
