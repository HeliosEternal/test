use std::mem::discriminant;
use fastwebsockets::WebSocketError;




pub fn eq_websocket_close_error(src: &WebSocketError) -> bool {
      return eq_websocket_error(src, &WebSocketError::ConnectionClosed);
}
pub fn eq_websocket_error(src: &WebSocketError, target: &WebSocketError) -> bool {
      return discriminant(src) == discriminant(target);
}