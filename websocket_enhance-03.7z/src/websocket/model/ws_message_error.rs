use std::fmt;

// 定义一个新的错误类型，其 Err 变体包含一个 String 对象
// 定义错误类型
#[derive(Debug)]
pub struct WSMessageError {
    pub code: u16,
    pub msg: String,
    pub ext_msg: Option<String>,
}

impl WSMessageError {
    pub fn error_msg(&self) -> String {
        let ext_msg = self.ext_msg.as_ref();
        if let Some(ext_msg) = ext_msg {
            format!("{}, {}", self.msg, ext_msg)
        } else {
            format!("{}", self.msg)
        }
    }
}

// 实现 Display trait，以便可以将 MyError 类型转换为字符串

// 实现 `Display` 特征用于格式化错误消息
// 实现 `Display` 特征用于格式化错误消息
impl fmt::Display for WSMessageError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "code: {}, msg: {}, ext_msg: {:?}", self.code, self.msg, self.ext_msg)
    }
}

// 实现 Error trait，以便可以将 MyError 类型转换为标准库的错误类型
impl std::error::Error for WSMessageError {}


impl From<anyhow::Error> for WSMessageError {
    fn from(error: anyhow::Error) -> Self {
        WSMessageError {
            code: 500,
            msg: error.to_string(),
            ext_msg: None,
        }
    }
}

// 定义错误码和消息的宏
#[macro_export]
// 定义错误码和消息的宏
// 定义宏来创建带有详细消息的错误
macro_rules! define_error_with_detail {
    ($name:ident, $code:expr, $default_msg:expr) => {
        pub fn $name(detail: &str) -> WSMessageError {
            WSMessageError {
                code: $code,
                msg: format!("{}", $default_msg),
                ext_msg: Some(detail.to_string())
            }
        }
    };
}

// 定义宏来创建不带详细消息的错误
#[macro_export]
macro_rules! define_error {
    ($name:ident, $code:expr, $default_msg:expr) => {
        pub fn $name() -> WSMessageError {
            WSMessageError {
                code: $code,
                msg: $default_msg.to_string(),
                  ext_msg: None
            }
        }
    };
}
// 定义一些常见的错误码和消息
/// js无缝调用lua，lua无缝调用rust/c/c++    满足 速度 性能 体积，配合前端大生态UI，桌面软件的最佳之选。
impl WSMessageError {
    define_error!(not_found, 404, "not found url");

    define_error_with_detail!(param_validate, 401, "param validate");

    define_error!(unknown_error, 409, "unknown error");
}


#[test]
fn test() {
    let err = WSMessageError::param_validate("name is empty").error_msg();
    println!("{}", err);
}