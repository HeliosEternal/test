use std::fmt;
use serde::{Deserialize, Serialize};
use crate::websocket::model::request_payload::{RequestBody};
use crate::websocket::model::response_payload::{ResponseBody};


/// 由于websocket是一个全双工协议，所以需要一个消息结构体来封装请求和响应， A作为客户端 既可以对 B 服务端发送请求消息，也可以对B进行发送响应消息，反之B亦然
// 通用的消息结构体
#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct WSMessage {
    pub header: Header,   // header数据
    pub url: String, // 请求的路由handler
    pub body: MessageBody,   // 泛型 T，用于存储请求或响应的业务数据 RequestMessage 或者 ResponseMessage
    pub file_stream_metadata: Option<FileStreamMetadata>, // 文件元数据,包含了二进制数据
}


// 请求响应枚举，只有这两种
#[derive(Debug, Serialize, Deserialize,Clone)]
#[serde(tag = "type", content = "content")]
pub enum MessageBody {
    Request(RequestBody), // 代表消息是请求
    Response(ResponseBody), // 代表消息是响应
}


#[derive(Debug, Serialize, Deserialize,Clone)]
pub struct Header {
    pub app_id: String, // 每个小程序应用的id
    pub request_id: String, // 当前请求的唯一ID
    pub version: u8, // 协议版本
    pub created_date: String, // 创建请求的时间（时间戳）
    pub ext_data: Option<serde_json::Map<String, serde_json::Value>>, // 扩展header，增加一些额外的自定义数据
}


#[derive(Serialize, Deserialize, Clone)]
pub struct FileStreamMetadata {
    pub total_files: u32,  // 要传输的文件总数
    pub file_index: u32,  // 当前文件的索引，支持传输多个文件
    pub name: String,    // 文件名
    pub stream_type: String, // 文件类型
    pub stream_length: u64, // 文件总大小
    pub chunk_total: usize,  // 文件总分块数
    pub chunk_index: usize,  // 当前传输的分块索引
    pub is_last_chunk: bool, // 是否是最后一个分块
    pub chunk_hash: String, // 当前分块的哈希值（例如 SHA-256 或 MD5）
    pub chunk_binary_stream: Option<Vec<u8>>, // 二进制流数据
}

// 手动实现 Debug 特性 不要打印 chunk_binary_stream，这是二进制数据 打印会很卡
impl fmt::Debug for FileStreamMetadata {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FileStreamMetadata")
            .field("total_files", &self.total_files)
            .field("file_index", &self.file_index)
            .field("name", &self.name)
            .field("stream_type", &self.stream_type)
            .field("stream_length", &self.stream_length)
            .field("chunk_total", &self.chunk_total)
            .field("chunk_index", &self.chunk_index)
            .field("is_last_chunk", &self.is_last_chunk)
            .field("chunk_hash", &self.chunk_hash)
            .field("chunk_binary_stream_length", &self.chunk_binary_stream.as_ref().map(|v| v.len())) // 只打印长度
            .finish()
    }
}


