use std::fmt::{Debug, Formatter};
use bytes::BytesMut;

pub struct ByteArrayMultipartFile {
    pub name: String,
    pub file_ext: String,
    pub length: u64,
    pub bytes_mut: BytesMut,
}

impl Default for ByteArrayMultipartFile {
    fn default() -> Self {
        ByteArrayMultipartFile {
            name: "".to_string(),
            file_ext: "".to_string(),
            length: 0,
            bytes_mut: BytesMut::new(),
        }
    }
}

impl Clone for ByteArrayMultipartFile {
    fn clone(&self) -> Self {
        ByteArrayMultipartFile {
            name: self.name.clone(),
            file_ext: self.file_ext.clone(),
            length: self.length,
            bytes_mut: self.bytes_mut.clone(),
        }
    }
}

impl Debug for ByteArrayMultipartFile {
    fn fmt(&self, f: &mut Formatter<'_>) -> std::fmt::Result {
        write!(f, "ByteArrayMultipartFile {{ name: {}, file_ext: {}, length: {}, bytes_mut: {} }}",
               self.name, self.file_ext, self.length, self.bytes_mut.len())
    }
}