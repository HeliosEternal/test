use std::future::Future;
use std::pin::Pin;
use std::sync::Arc;
use async_trait::async_trait;
use crate::websocket::model::websocket_message::WSMessage;

pub mod request_handler;
pub mod router;
pub mod decode_binary_stream;
pub mod dispatch_handler;


// 定义一个 FromRequest 特征，用于从请求中提取参数
#[async_trait]
trait FromRequest: Sized + Send {
    async fn from_request(arc_ws_message: Arc<WSMessage>) -> anyhow::Result<Self>;
}


trait Handler<Args>: Send + Sync {
    fn call(&self, args: Args) -> Pin<Box<dyn Future<Output=anyhow::Result<WSMessage>> + Send>>;
}


macro_rules! impl_from_request_for_multiple_args {
  ($(($($ty:ident),*)),*) => {
    $(
      // 为多参数组合生成 `FromRequest` 的实现
      #[async_trait]
      impl<$($ty: FromRequest),*> FromRequest for ($($ty,)*) {
       async fn from_request(arc_ws_message: Arc<WSMessage>) -> anyhow::Result<Self> {
          // 尝试为每个参数调用 `FromRequest::from_request`，并将结果组合成一个元组
          Ok(($($ty::from_request(arc_ws_message.clone()).await?,)*))
        }
      }
      // 为多参数组合生成 `Handler` 特征的实现
      impl<F, Fut, $($ty),*> Handler<($($ty,)*)> for F
      where
        F: Fn($($ty),*) -> Fut + Send + Sync + 'static,
        Fut: Future<Output = anyhow::Result<WSMessage>> + Send + 'static,
        $($ty: FromRequest + 'static),*,
      {
        fn call(&self, args: ($($ty,)*)) -> Pin<Box<dyn Future<Output = anyhow::Result<WSMessage>> + Send>> {
          // 解包参数，并依次传递给处理器函数
          let ($($ty,)*) = args;
          let fut = (self)($($ty,)*);
          Box::pin(fut)
        }
      }
    )*
  };
}



// 生成 FromRequest 实现，支持单个参数到四个参数的独立传递
impl_from_request_for_multiple_args! {
  (T1),
  (T1, T2),
  (T1, T2, T3),
  (T1, T2, T3, T4)
}


/*
参考案例，手动实现了两个参数的解析


#[async_trait]
impl<T1: FromRequest, T2: FromRequest> FromRequest for (T1, T2) {
  async fn from_request(arc_ws_message: Arc<WSMessage>) -> anyhow::Result<Self> {
    Ok((T1::from_request(arc_ws_message.clone()).await?, T2::from_request(arc_ws_message.clone()).await?))
  }
}


// 为 (T1, T2) 生成 Handler 特征的实现
// 这个地方比较少见和巧妙， 注意这里的Handler 特征的实现，用于将处理器函数转换为一个异步函数，以适应路由处理流程。
// for F F是一个函数类型，用于处理请求，返回一个 Future， 因此我们可以将自定义的函数 add_route 添加到路由中去
impl<F, Fut, T1, T2> Handler<(T1, T2)> for F
where
  F: Fn(T1, T2) -> Fut + Send + Sync + 'static,
  Fut: Future<Output=WSMessage> + Send + 'static,
  T1: FromRequest + 'static,
  T2: FromRequest + 'static,
{
  fn call(&self, args: (T1, T2)) -> Pin<Box<dyn Future<Output=WSMessage> + Send>> {
    let (t1, t2) = args;
    let fut = (self)(t1, t2);
    Box::pin(fut)
  }
}*/


