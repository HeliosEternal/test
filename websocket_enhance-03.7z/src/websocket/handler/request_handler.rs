use std::sync::Arc;
use anyhow::anyhow;
use async_trait::async_trait;
use serde::de::DeserializeOwned;
use crate::websocket::handler::decode_binary_stream::get_binary_stream;
use crate::websocket::handler::FromRequest;
use crate::websocket::model::binary_stream_file::ByteArrayMultipartFile;
use crate::websocket::model::websocket_message::{MessageBody, WSMessage};


// Json 参数的实现，从请求体中解析 JSON 数据
#[derive(Debug)]
pub struct Json<T>(pub T);


#[async_trait]
impl<T> FromRequest for Json<T>
where
    T: DeserializeOwned + Send, // 反序列化所需的约束
{
    async fn from_request(arc_ws_message: Arc<WSMessage>) -> anyhow::Result<Self> {
        // 尝试将请求体解析为 JSON 对象
        let mut json_value: Option<&serde_json::Value> = None;
        match &arc_ws_message.body {
            MessageBody::Request(request_message) => {
                let body = &request_message.data;
                json_value = Some(body);
            }
            MessageBody::Response(response_message) => {
                let body = &response_message.data;
                if let Some(payload) = &body {
                    json_value = Some(payload);
                }
            }
        }
        if let Some(value) = json_value {
            let result = serde_json::from_str(value.to_string().as_str())
                .map(Json)
                .map_err(|e| anyhow!(format!("Failed to parse JSON: {}", e)));
            return result;
        }
        let error_msg = "json value is empty".to_string();
        Err(anyhow!(error_msg))
    }
}


pub struct File(pub Option<Vec<ByteArrayMultipartFile>>);


impl File {
    // 空file，当前文件还没传输完成
    pub fn default() -> Self {
        File(None)
    }
}


#[async_trait]
impl FromRequest for File
{
    async fn from_request(arc_ws_message: Arc<WSMessage>) -> anyhow::Result<Self> {
        if arc_ws_message.file_stream_metadata.is_some() {
            let vec_stream_result = get_binary_stream(arc_ws_message.clone()).await;
            match vec_stream_result {
                Ok(value) => {
                    Ok(File(Some(value)))
                }
                Err(err) => {
                    return Err(err);
                }
            }
        } else {
            let error_msg = "can not find binary stream".to_string();
            Err(anyhow!(error_msg))
        }
    }
}
