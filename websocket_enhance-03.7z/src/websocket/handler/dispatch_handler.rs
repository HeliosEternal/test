use std::sync::Arc;
use anyhow::anyhow;
use log::error;
use crate::websocket::client_sender_manager;
use crate::websocket::model::build_ws_message::{build_error_response_ws_message, build_ok_response_ws_message, build_ws_error_response_ws_message};
use crate::websocket::handler::decode_binary_stream::append_stream;
use crate::websocket::handler::router::Router;
use crate::websocket::model::binary_stream_file::ByteArrayMultipartFile;
use crate::websocket::model::websocket_message::{MessageBody, WSMessage};
use crate::websocket::model::ws_message_error::WSMessageError;


const API_VERSION: &'static str = "/api/v1";

// 发送流分块的消息路由
const SEND_STREAM_CHUNK: &'static str = "/binary-stream/send-chunk/";

// 确认流分块的消息路由
const ACK_STREAM_CHUNK: &'static str = "/binary-stream/ack-chunk";


pub async fn dispatch_handler(router: &Router, ws_message: WSMessage) {
    println!("dispatch_handler: {}", ws_message.url);
    let mut response_ws_message: Option<anyhow::Result<WSMessage>> = None;

    let arc_ws_message: Arc<WSMessage> = Arc::new(ws_message);
    let request_url = arc_ws_message.url.as_str();

    // 接收来自对方的分块传输，我要在这里处理接收分块，并发送确认分块消息给对方
    if request_url.starts_with(SEND_STREAM_CHUNK) {
        // 处理发送流分块的消息
        let option = append_stream(arc_ws_message.clone()).await;
        if option.is_some() {
            // 分块传输完毕，调用指定的handler
            response_ws_message = Some(call_handler(request_url, router, arc_ws_message.clone()).await);
        } else {
            // 回复确认分块接收完毕
            println!("分块传输中，等待下一次分块");
            response_ws_message = Some(Ok(build_ok_response_ws_message(arc_ws_message.clone(), ACK_STREAM_CHUNK)));
        }
    } else if request_url.starts_with(ACK_STREAM_CHUNK) {
        // 来自对方的确认分块流，继续传输下一个分块流给对方  这里需要通道，每个发送二进制流的消息对应一个通道在这里发送
    } else {
        // 其他消息，调用对应的处理器函数
        response_ws_message = Some(call_handler(request_url, router, arc_ws_message.clone()).await);
    }


    return match response_ws_message {
        Some(result) => {
            match result {
                Ok(ws_message) => {
                    // 这里拿到的ws_message是正确的，然后我们需要判断响应的消息是否包含二进制流，如果包含，我们需要分块传输，如果不包含直接响应发送走
                    send_ok_response(ws_message);
                }
                Err(error) => {
                    let ws_message = build_error_response_ws_message(arc_ws_message.clone(), error);
                    send_response_to_client(ws_message);
                }
            }
        }
        None => {
            println!("未找到对应的处理器函数，返回默认的错误消息");
            let ws_message = build_ws_error_response_ws_message(arc_ws_message.clone(), WSMessageError::not_found());
            send_response_to_client(ws_message);
        }
    };
}


async fn call_handler(request_url: &str, router: &Router, ws_message: Arc<WSMessage>) -> anyhow::Result<WSMessage> {
    let handler_result = router.get_route_handler(request_url);
    return match handler_result {
        Some(handler) => {
            // 调用处理器函数处理请求
            handler(ws_message).await
        }
        None => {
            // 处理未找到的处理器函数
            println!("未找到的处理器函数: {}", request_url);
            Ok(build_ws_error_response_ws_message(ws_message.clone(), WSMessageError::not_found()))
        }
    };
}


fn send_response_to_client(ws_message: WSMessage) {
    println!("send_response_to_client: {}", ws_message.url);
    client_sender_manager::GLOBAL_CLIENT_SENDER_MANAGER.send_response(ws_message)
}


pub fn send_ok_response(response_ws_message: WSMessage) {
    match &response_ws_message.body {
        MessageBody::Request(_) => {
            error!("发送响应的时候只能是ResponseBody")
        }
        MessageBody::Response(request_body) => {
            match &request_body.file_stream_data {
                None => {
                    send_response_to_client(response_ws_message);
                }
                Some(data) => {
                    // 循环分块传输， 这里要使用通道，接收来自对方的确认，然后这里继续发送下一个分块
                }
            }
        }
    }
}

