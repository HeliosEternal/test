use std::mem;
use std::sync::Arc;
use std::time::Duration;
use anyhow::anyhow;
use bytes::{BytesMut};
use moka::future::{Cache};
use tokio::sync::Mutex;
use crate::websocket::model::binary_stream_file::ByteArrayMultipartFile;
use crate::websocket::model::websocket_message::{MessageBody, FileStreamMetadata, WSMessage};


lazy_static::lazy_static! {
  // 支持缓存多个文件流
 static ref GLOBAL_BINARY_STREAM_CACHE: Cache<String, Arc<Mutex<ByteArrayMultipartFile>>>= {
      // 创建一个缓存，容量为 200，条目
  let cache = Cache::builder()
    .max_capacity(200)
    // time_to_live（生存时间）参数设置缓存条目的固定存活时间。无论条目是否被访问，只要存活时间到期，条目就会被自动移除
    .time_to_live(Duration::from_secs(60 * 20))// 最大存活20分钟 防止过大的文件，20分钟本地传输的文件已经非常大了
    // time_to_idle（闲置时间）参数设置条目在闲置状态下的存活时间。如果在指定的时间内条目没有被访问，它就会被移除。
    .time_to_idle(Duration::from_secs(60 * 5))// 最大空闲5分钟 没有get set操作， 5分钟传输一个分块 已经很慢了，一般分块 我们是512KB
    .support_invalidation_closures() // 开启闭包删除策略，需要额外维护数据结构
    .build();
 cache
 };
}


/**
如果websocket掉线，断开，则清除缓存的二进制流，防止内存泄露
 */
pub fn remove_app_id_binary_cache(app_id: String) {
    // 遍历缓存中的所有键，并移除以 "app" 开头的键
    let arc_app_id = Arc::new(app_id);
    GLOBAL_BINARY_STREAM_CACHE.iter().for_each(|(key, _)| {
        if key.starts_with(arc_app_id.as_str()) {
            let app_id = arc_app_id.clone();
            tokio::spawn(async move {
                GLOBAL_BINARY_STREAM_CACHE.invalidate(app_id.as_str()).await;
            });
        }
    });
}


pub async fn get_binary_stream(ws_message: Arc<WSMessage>) -> anyhow::Result<Vec<ByteArrayMultipartFile>> {
    let meta_data_ref = &ws_message.file_stream_metadata;
    if meta_data_ref.is_none() {
        return Err(anyhow!("ws message is not contains binary stream, {:?}",ws_message));
    }
    let meta_data = meta_data_ref.as_ref().unwrap();
    let header = &ws_message.header;

    let total_files = meta_data.total_files;

    let app_id = header.app_id.as_str();
    let package_id = header.request_id.as_str();

    let mut vec_binary: Vec<ByteArrayMultipartFile> = Vec::new();
    for index in 0..total_files {
        let key = format!("{}_{}_{}", app_id, package_id, index);
        let value_option = GLOBAL_BINARY_STREAM_CACHE.remove(&key).await;
        if value_option.is_none() {
            return Err(anyhow!("get binary stream not found, key: {}",key));
        }
        // 上面的锁已经释放了，这里可以再次获取
        let arc_value_lock = value_option.unwrap();
        let mut value = arc_value_lock.lock().await;
        // 获取Arc的所有权并对其进行操作
        let owned_value = mem::take(&mut *value);
        vec_binary.push(owned_value)
    }
    // 获取Arc的所有权并对其进行操作
    Ok(vec_binary)
}


// 流可能有或者没有，有的话，中途可能获取错误，比如超过最大限制大小，等异常错误返回，如果一切正常
// meta_data 只会在这里使用一次，在外面把所有权传递过来 可以使用 ()option的take方法
pub async fn append_stream(ws_message: Arc<WSMessage>) -> Option<()> {
    let meta_data_ref = &ws_message.file_stream_metadata;
    if meta_data_ref.is_none() {
        return None;
    }
    let header = &ws_message.header;
    let meta_data = meta_data_ref.as_ref().unwrap();
    let app_id = header.app_id.as_str();
    let package_id = header.request_id.as_str();
    let file_index = meta_data.file_index;
    let key = format!("{}_{}_{}", app_id, package_id, file_index);


    let total_files = meta_data.total_files;


    if !GLOBAL_BINARY_STREAM_CACHE.contains_key(key.as_str()) {
        let name = meta_data.name.clone();
        let file_ext = meta_data.stream_type.clone();
        let length = meta_data.stream_length;
        let bytes_mut = BytesMut::with_capacity(length as usize);
        let byte_array_stream = ByteArrayMultipartFile {
            name,
            file_ext,
            length,
            bytes_mut,
        };
        GLOBAL_BINARY_STREAM_CACHE.insert(key.clone(), Arc::new(Mutex::new(byte_array_stream))).await;
    }


    // 代码块 让锁尽快释放掉，后面可能会再次用到
    {
        let value_option = GLOBAL_BINARY_STREAM_CACHE.get(key.as_str()).await;
        let arc_value_lock = value_option.unwrap().clone();


        let mut value = arc_value_lock.lock().await;

        match &meta_data.chunk_binary_stream {
            Some(chunk_binary_stream) => {
                // println!("插入分块：{}", chunk_binary_stream.len());
                value.bytes_mut.extend_from_slice(chunk_binary_stream);
            }
            None => {
                return None;
            }
        }
    }
    // 判断分块是否传输完毕
    return if meta_data.is_last_chunk && file_index == total_files - 1 {
        // 最后一个处理完毕
        Some(())
    } else {
        None
    };
}





