use serde::{Deserialize, Serialize};

pub mod request_payload;
pub mod response_payload;
pub mod websocket_message;
pub mod binary_stream_file;


#[derive(Debug, Serialize, Deserialize)]
pub struct WSContext {
    pub app_id: String,
    pub user_id: String,
    pub session_id: String,
}