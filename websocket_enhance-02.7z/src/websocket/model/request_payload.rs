use serde::{Deserialize, Serialize};


#[derive(Debug, Serialize, Deserialize,Clone)]
pub struct RequestBody {
    pub data: serde_json::Value, // 承载业务的json数据 请求必然有值，响应可选值
}


#[derive(Debug, Serialize, Deserialize, PartialEq, Eq, Hash, Clone)]
pub enum RequestType {
    CallLuaScript,
    FileUpload,
    ScriptRun,
    // 添加更多的请求类型
    Other, // 用于扩展
}


#[derive(Debug, Serialize, Deserialize)]
pub struct ScriptFunctionTask {
    /// lua 文件的相对路径
    pub lua_file_path: String,
    /// 需要调用的lua函数名称
    pub function_name: String,
    /// 函数参数，json数据，数组形式，支持多个参数
    pub function_param: serde_json::Value,
}




