use bytes::BytesMut;

pub struct ByteArrayMultipartFile {
    pub name: String,
    pub file_ext: String,
    pub length: u64,
    pub bytes_mut: BytesMut,
}

impl Default for ByteArrayMultipartFile {
    fn default() -> Self {
        ByteArrayMultipartFile {
            name: "".to_string(),
            file_ext: "".to_string(),
            length: 0,
            bytes_mut: BytesMut::new(),
        }
    }
}