use std::collections::HashMap;
use std::future::Future;
use std::pin::Pin;
use std::sync::Arc;
use anyhow::anyhow;
use serde::{Deserialize, Serialize};
use serde_json::json;

use crate::websocket::handler::{FromRequest, Handler};
use crate::websocket::handler::request_handler::Json;
use crate::websocket::model::request_payload::RequestBody;
use crate::websocket::model::response_payload::ResponseBody;
use crate::websocket::model::websocket_message::{Header, WSMessage};
use crate::websocket::model::websocket_message::MessageBody;

// Handler 是一个异步函数类型，返回一个 Future
type HandlerFn = Arc<dyn Fn(WSMessage) -> Pin<Box<dyn Future<Output=anyhow::Result<WSMessage>> + Send>> + Send + Sync>;


// 路由器结构
pub struct Router {
    routes: HashMap<String, HandlerFn>,
}


impl Router {
    pub fn new() -> Self {
        Router {
            routes: HashMap::new(),
        }
    }


    // 添加路由的方法
    pub fn add_route<H, Args>(&mut self, path: &str, handler: H)
    where
        H: Handler<Args> + 'static,
        Args: FromRequest,
    {
        // 克隆 `handler` 以避免它被移动到闭包内
        let handler = Arc::new(handler);
        let route_handler = Arc::new(move |req: WSMessage| {
            let arc_ws_message: Arc<WSMessage> = Arc::new(req);
            let handler = handler.clone();
            // 创建一个异步块，并返回一个 Future
            let fut = async move {
                // 从请求中提取参数
                let args_result = Args::from_request(arc_ws_message).await;
                if let Err(e) = args_result {
                    return Err(anyhow!("Failed to parse request parameters: {}", e));
                }

                let args = args_result.unwrap();

                // 调用处理器，并返回它生成的 Future
                handler.call(args).await
            };
            // 将异步块转换为 Pin<Box<dyn Future>>
            /*  async 块实际上生成了一个匿名的具体 Future 类型，它实现了 Future 特征。
              你可以将这个具体的 Future 类型转换为特征对象 dyn Future，这是因为 Rust 允许将实现某个特征的具体类型转换为特征对象。
              特征对象 dyn Future 允许动态调度，可以处理不同类型的 Future。
              因此，async 代码块生成的匿名 Future 类型和 dyn Future 之间的转换是合法且有效的，因为底层实现已经确保了 async 代码块生成的类型符合 Future 特征的约束。*/
            Box::pin(fut) as Pin<Box<dyn Future<Output=anyhow::Result<WSMessage>> + Send>>
        }) as HandlerFn;
        self.routes.insert(path.to_string(), route_handler);
    }


    // 处理请求
    pub async fn handle_request(&self, req: WSMessage) -> anyhow::Result<WSMessage> {
        if let Some(handler) = self.routes.get(&req.url) {
            handler(req).await
        } else {
            let ws = WSMessage {
                header: Header {
                    app_id: "".to_string(),
                    package_id: "".to_string(),
                    version: 0,
                    created_date: 0.0,
                    ext_data: None,
                },
                url: "".to_string(),
                body: MessageBody::Response(ResponseBody {
                    code: 404,
                    msg: "not found url".to_string(),
                    data: None,
                }),
                file_stream_metadata: None,
            };
            Ok(ws)
        }
    }
}


pub async fn hello(req: Json<UserInfo>) -> anyhow::Result<WSMessage> {
    println!("receive request: {:?}", req);
    let ws_message = WSMessage {
        header: Header {
            app_id: "".to_string(),
            package_id: "".to_string(),
            version: 0,
            created_date: 0.0,
            ext_data: None,
        },
        url: "/404".to_string(),
        body: MessageBody::Response(
            ResponseBody {
                code: 200,
                msg: "success".to_string(),
                data: Some(
                    json!({
                        "name": "lanwenxi",
                        "age":15,
                        "address": "湖北省武汉市"
                    })
                ),
            }),
        file_stream_metadata: None,
    };
    Ok(ws_message)
}


#[derive(Debug, Serialize, Deserialize)]
pub struct UserInfo {
    pub name: String,
    pub age: i32,
    pub address: String,
}

