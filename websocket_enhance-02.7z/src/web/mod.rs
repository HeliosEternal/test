use std::collections::HashMap;
use std::sync::Arc;
use std::future::Future;
use std::pin::Pin;
use serde::de::DeserializeOwned;

// 模拟 HTTP 请求和响应
#[derive(Debug)]
struct Request {
    path: String,
    query: HashMap<String, String>,
    headers: HashMap<String, String>,
    body: String
}

#[derive(Debug)]
struct Response {
    body: String,
}

// 定义一个 FromRequest 特征，用于从请求中提取参数
trait FromRequest: Sized {
    fn from_request(req: &Request) -> Result<Self, String>;
}

// Path 参数的实现，从 URL 中提取路径参数
#[derive(Debug)]
struct Path(String);

impl FromRequest for Path {
    fn from_request(req: &Request) -> Result<Self, String> {
        Ok(Path(req.path.clone()))
    }
}

// Query 参数的实现，从 URL 中提取查询参数
#[derive(Debug)]
struct Query(HashMap<String, String>);

impl FromRequest for Query {
    fn from_request(req: &Request) -> Result<Self, String> {
        Ok(Query(req.query.clone()))
    }
}


// Header 参数的实现，从 Header 中提取查询参数
#[derive(Debug)]
struct Header(HashMap<String, String>);

impl FromRequest for Header {
    fn from_request(req: &Request) -> Result<Self, String> {
        Ok(Header(req.headers.clone()))
    }
}

// Json 参数的实现，从请求体中解析 JSON 数据
#[derive(Debug)]
struct Json<T>(T);

impl<T> FromRequest for Json<T>
where
    T: DeserializeOwned, // 反序列化所需的约束
{
    fn from_request(req: &Request) -> Result<Self, String> {
        // 尝试将请求体解析为 JSON 对象
        serde_json::from_str(&req.body)
            .map(Json)
            .map_err(|e| format!("Failed to parse JSON: {}", e))
    }
}


// 使用宏生成多个 FromRequest 的实现，最多支持四个参数的元组

/**
 // 为 (T1, T2) 生成 FromRequest 的实现，因此当调用 带有元组的参数 是可以调用from_request，会去分别调用 from_request
impl<T1: FromRequest, T2: FromRequest> FromRequest for (T1, T2) {
    fn from_request(req: &Request) -> Result<Self, String> {
        Ok((T1::from_request(req)?, T2::from_request(req)?))
    }
}

// 为 (T1, T2) 生成 Handler 特征的实现
// 这个地方比较少见和巧妙， 注意这里的Handler 特征的实现，用于将处理器函数转换为一个异步函数，以适应路由处理流程。
//  for F   F是一个函数类型，用于处理请求，返回一个 Future， 因此我们可以将自定义的函数 add_route 添加到路由中去
impl<F, Fut, T1, T2> Handler<(T1, T2)> for F
where
    F: Fn(T1, T2) -> Fut + Send + Sync + 'static,
    Fut: Future<Output = Response> + Send + 'static,
    T1: FromRequest + 'static,
    T2: FromRequest + 'static,
{
    fn call(&self, args: (T1, T2)) -> Pin<Box<dyn Future<Output = Response> + Send>> {
        let (t1, t2) = args;
        let fut = (self)(t1, t2);
        Box::pin(fut)
    }
}

 */

macro_rules! impl_from_request_for_multiple_args {
    ($(($($ty:ident),*)),*) => {
        $(
            // 为多参数组合生成 `FromRequest` 的实现
            impl<$($ty: FromRequest),*> FromRequest for ($($ty,)*) {
                fn from_request(req: &Request) -> Result<Self, String> {
                    // 尝试为每个参数调用 `FromRequest::from_request`，并将结果组合成一个元组
                    Ok(($($ty::from_request(req)?,)*))
                }
            }
            // 为多参数组合生成 `Handler` 特征的实现
            impl<F, Fut, $($ty),*> Handler<($($ty,)*)> for F
            where
                F: Fn($($ty),*) -> Fut + Send + Sync + 'static,
                Fut: Future<Output = Response> + Send + 'static,
                $($ty: FromRequest + 'static),*
            {
                fn call(&self, args: ($($ty,)*)) -> Pin<Box<dyn Future<Output = Response> + Send>> {
                    // 解包参数，并依次传递给处理器函数
                    let ($($ty,)*) = args;
                    let fut = (self)($($ty,)*);
                    Box::pin(fut)
                }
            }
        )*
    };
}


// 生成 FromRequest 实现，支持单个参数到四个参数的独立传递
impl_from_request_for_multiple_args! {
    (T1),
    (T1, T2),
    (T1, T2, T3),
    (T1, T2, T3, T4)
}



// Handler 是一个异步函数类型，返回一个 Future
type HandlerFn = Arc<dyn Fn(Request) -> Pin<Box<dyn Future<Output=Response> + Send>> + Send + Sync>;

// 路由器结构
struct Router {
    routes: HashMap<String, HandlerFn>,
}

impl Router {
    fn new() -> Self {
        Router {
            routes: HashMap::new(),
        }
    }

    // 添加路由的方法
    fn add_route<H, Args>(&mut self, path: &str, handler: H)
    where
        H: Handler<Args> + 'static,
        Args: FromRequest + 'static,
    {
        let handler = Arc::new(move |req: Request| {
            let args = Args::from_request(&req).unwrap(); // 简化处理错误
            let fut = handler.call(args);
            fut
        }) as HandlerFn;
        self.routes.insert(path.to_string(), handler);
    }

    // 处理请求
    async fn handle_request(&self, req: Request) -> Response {
        if let Some(handler) = self.routes.get(&req.path) {
            handler(req).await
        } else {
            Response {
                body: "404 Not Found".into(),
            }
        }
    }
}

// Handler 特征，用于约束处理函数的类型
trait Handler<Args>: Send + Sync {
    fn call(&self, args: Args) -> Pin<Box<dyn Future<Output=Response> + Send>>;
}

// Handler 特征的实现，用于异步函数


// 示例处理器函数
async fn hello(Path(path): Path, Query(query): Query, Header(header): Header) -> Response {
    println!("Path: {}, Query: {:?}, Header: {:?}", path, query, header);
    Response {
        body: format!("Hello, {}!", path),
    }
}

// 示例处理器函数
async fn query_info(Path(path): Path, Query(query): Query, Header(header): Header) -> Response {
    println!("Path: {}, Query: {:?}, Header: {:?}", path, query, header);
    let info = format!("Query parameters: {:?}", query);
    Response { body: info }
}

// 主函数
#[tokio::test]
async fn main() {
    let mut router = Router::new();

    // 注册路由和处理函数
    router.add_route("/hello", hello);
    router.add_route("/query", query_info);

    // 模拟请求
    let req1 = Request {
        path: "/hello".into(),
        query: [("name".into(), "mini_app".into())].iter().cloned().collect(),
        headers: [("content_type".into(), "form-url".into())].iter().cloned().collect(),
        body: "".to_string(),
    };

    let req2 = Request {
        path: "/query".into(),
        query: [("name".into(), "Rust".into())].iter().cloned().collect(),
        headers: [("content_type".into(), "json".into())].iter().cloned().collect(),
        body: "".to_string(),
    };

    // 处理请求
    let res1 = router.handle_request(req1).await;
    let res2 = router.handle_request(req2).await;

    println!("{:?}", res1);
    println!("{:?}", res2);
}
