mod websocket;
mod web;

fn main() {
    println!("Hello, world!");
}
