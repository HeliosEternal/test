use std::sync::Arc;
use serde::Serialize;
use crate::util::time_util::get_milli_datetime;
use crate::websocket::model::response_payload::ResponseBody;
use crate::websocket::model::websocket_message::{Header, MessageBody, WSMessage};
use crate::websocket::model::ws_message_error::WSMessageError;

pub fn build_error_response_ws_message(request_ws_message: Arc<WSMessage>, error: anyhow::Error) -> WSMessage {
    let error_msg = WSMessageError::from(error);
    build_ws_error_response_ws_message(request_ws_message, error_msg)
}


pub fn build_ws_error_response_ws_message(request_ws_message: Arc<WSMessage>, ws_message_error: WSMessageError) -> WSMessage {
    let mut header = request_ws_message.header.clone();
    header.created_date = get_milli_datetime();
    let ws = WSMessage {
        header,
        url: "".to_string(),
        body: MessageBody::Response(ResponseBody {
            code: ws_message_error.code,
            msg: Some(ws_message_error.error_msg()),
            data: None,
            file_stream_data: None,
        }),
        file_stream_metadata: None,
    };
    ws
}



pub fn build_ok_response_ws_message<T: Serialize>(response_url: &str, mut header: Header, data_option: Option<T>) -> WSMessage {
    header.created_date = get_milli_datetime();
    header.ext_data = None;
    let json_value_data_option = data_option.map(|data| {
        serde_json::to_value(data).unwrap()
    });
    let ws = WSMessage {
        header,
        url: response_url.to_string(),
        body: MessageBody::Response(ResponseBody {
            code: 200,
            msg: None,
            data: json_value_data_option,
            file_stream_data: None,
        }),
        file_stream_metadata: None,
    };
    ws
}