use serde::{Deserialize, Serialize};
use crate::websocket::model::binary_stream_file::ByteArrayMultipartFile;


#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct ResponseBody {
    pub code: u16,       // 状态码，例如 200 成功，400 错误，500 服务端错误
    pub msg: Option<String>,      // 状态描述信息
    pub data: Option<serde_json::Value>,    // 返回的数据， 业务数据的结构体 对应的 json 类型
    #[serde(skip)]    //这个字段不参与反序列化，因为响应返回的字段 响应体返回，在dispatch_handler中内部处理分块发送和确认逻辑
    pub file_stream_data_vec: Option<Vec<ByteArrayMultipartFile>>,    // 返回的数据，也可以返回响应一个二进制数据流
}


// ACK属于分块传输的一种确认机制，在某些场景下，客户端需要确认分块是否传输成功，把找个结构体放在 ResponseData 的 data承载
#[derive(Debug, Serialize, Deserialize)]
pub struct FileChunkAck {
    pub chunk_index: usize,   // 确认的分块索引
    pub file_index: usize,   // 确认的是哪个文件
    pub success: bool,    // 确认是否成功
    pub error_message: Option<String>, // 错误信息（如果有）
}

impl FileChunkAck {
    pub fn new(chunk_index: usize, file_index: usize, success: bool, error_message: Option<String>) -> FileChunkAck {
        FileChunkAck {
            chunk_index,
            file_index,
            success,
            error_message,
        }
    }
}
