use dashmap::DashMap;
use tokio::sync::mpsc;
use lazy_static::lazy_static;
use crate::websocket::model::websocket_message::WSMessage;


lazy_static::lazy_static! {
 pub static ref GLOBAL_CLIENT_SENDER_MANAGER: ClientSenderManager= {
 ClientSenderManager::new()
 };
}


pub fn get_client_sender_manager() -> &'static GLOBAL_CLIENT_SENDER_MANAGER {
    return &GLOBAL_CLIENT_SENDER_MANAGER;
}


pub struct ClientSenderManager {
    pub client_sender_map: DashMap<String, mpsc::Sender<WSMessage>>,
}


impl ClientSenderManager {
    pub fn new() -> ClientSenderManager {
        ClientSenderManager {
            client_sender_map: DashMap::new(),
        }
    }


    pub fn add_client_sender(&self, app_id: &str, sender: mpsc::Sender<WSMessage>) {
        self.client_sender_map.insert(app_id.to_string(), sender);
    }


    pub fn get_client_sender(&self, app_id: &str) -> Option<mpsc::Sender<WSMessage>> {
        self.client_sender_map.get(app_id).map(|entry| entry.value().clone())
    }

    pub fn send_response(&self, response_data: WSMessage) {
        let app_id = response_data.header.app_id.clone();
        if let Some(sender) = self.get_client_sender(app_id.as_str()) {
            let result = sender.try_send(response_data);
            match result {
                Ok(_) => {
                    println!("app_id: {:?}, 发送响应消息成功", app_id);
                }
                Err(err) => {
                    println!("app_id: {}, 发送响应消息失败，错误信息：{}", app_id, err);
                }
            }
        }
    }


    pub fn remove_client_sender(&self, app_id: &str) {
        self.client_sender_map.remove(app_id);
    }
}
