use std::any::Any;
use std::sync::{Arc};
use std::time::Duration;
use anyhow::anyhow;
use dashmap::DashMap;
use moka::future::Cache;
use crate::websocket::model::binary_stream_file::{ByteArrayMultipartFile, ByteFileChunk, FileChunkReceiveStatus};
use crate::websocket::model::response_payload::FileChunkAck;
use crate::websocket::model::websocket_message::{FileStreamMetadata, WSMessage};


/// 使用滑动窗口传输文件的分块
/// 1. 一次性传输和分块传输，设置一个大小边界 比如 15MB以内（注意结合操作系统，框架来决定，不能太大，一般有限制），15MB以内一次性传输即可，超过分块传输
/// 2. 分块传输设置窗口大小，即每次批量发送和确认的分块大小，比如设置10个（考虑到本地传输效果良好，如果是远程降低到5个）
/// 3. 元素据携带本轮窗口的容量大小，便于确认数量，批量接收完一个窗口的分块后，发送确认消息给发送方
/// 4. 发送方发送完一个窗口的分块之后，阻塞等待，接收方的确认消息，一旦确认完毕，继续发送下一个窗口的分块
/// 5. 在整个分块任务传输过程中，




/**
1. 发送方可以循环依次按顺序发送分块，不用等待确认，但是仍然需要确认机制，异步确认，对于有问题或者发送失败的分块，超时未确认的分块需要重新发送，保证分块的传输的完整性


2. 接收方接收来自发送的分块，每次都进行确认，确认有成功和失败两种状态，可以附带上原因，让发送方重新发送


3. 可能中间某个分块重发，需要替换和衔接文件中某个区间的分块的字节，做好处理，一个是发送方要读取指定分块的区间字节，一个是接收方要写入指定的分块区间字节
 发送方通过seek读取，接收方使用 BTreeMap


 */




lazy_static::lazy_static! {
 // 支持缓存多个文件流 , key是app_id+request_id value是带锁的顺序map，因为涉及异步多线程修改，所以加锁了
static ref GLOBAL_BINARY_STREAM_CHUNK_CACHE: Cache<String, Arc<ByteFileChunk>>= {
   // 创建一个缓存，容量为 200，条目
 let cache = Cache::builder()
  .max_capacity(200)
  // time_to_live（生存时间）参数设置缓存条目的固定存活时间。无论条目是否被访问，只要存活时间到期，条目就会被自动移除
  .time_to_live(Duration::from_secs(60 * 20))// 最大存活20分钟 防止过大的文件，20分钟本地传输的文件已经非常大了
  // time_to_idle（闲置时间）参数设置条目在闲置状态下的存活时间。如果在指定的时间内条目没有被访问，它就会被移除。
  .time_to_idle(Duration::from_secs(60 * 5))// 最大空闲5分钟 没有get set操作， 5分钟传输一个分块 已经很慢了，一般分块 我们是512KB
  .support_invalidation_closures() // 开启闭包删除策略，需要额外维护数据结构
  .build();
cache
};
}










pub async fn get_binary_stream(ws_message: Arc<WSMessage>) -> anyhow::Result<Vec<ByteArrayMultipartFile>> {
    let meta_data_ref = &ws_message.file_stream_metadata;
    if meta_data_ref.is_none() {
        return Err(anyhow!("ws message is not contains binary stream, {:?}",ws_message));
    }
    let meta_data = meta_data_ref.as_ref().unwrap();
    let header = &ws_message.header;


    let total_files = meta_data.total_files;


    let app_id = header.app_id.as_str();
    let request_id = header.request_id.as_str();


    let mut vec_binary: Vec<ByteArrayMultipartFile> = Vec::new();
    for file_index in 0..total_files {
        let key = format!("{}_{}_{}", app_id, request_id, file_index);
        let value_option = GLOBAL_BINARY_STREAM_CHUNK_CACHE.remove(&key).await;
        if value_option.is_none() {
            return Err(anyhow!("get binary stream not found, key: {}",key));
        }
        let arc_value = value_option.unwrap();
        let byte = arc_value.convert_byte_array_multipart_file();
        vec_binary.push(byte);
    }
    Ok(vec_binary)
}


// 流可能有或者没有，有的话，中途可能获取错误，比如超过最大限制大小，等异常错误返回，如果一切正常
// meta_data 只会在这里使用一次，在外面把所有权传递过来 可以使用 ()option的take方法
pub async fn receive_byte_file_chunk(file_stream_metadata_option: Option<FileStreamMetadata>, ws_message: Arc<WSMessage>) -> anyhow::Result<FileChunkReceiveStatus<FileChunkAck>> {
    if file_stream_metadata_option.is_none() {
        return Err(anyhow!("can not find file stream metadata"));
    }
    let meta_data = file_stream_metadata_option.unwrap();
    if meta_data.chunk_binary_stream.is_none() {
        return Err(anyhow!("can not find  byte chunk of file stream metadata"));
    }
    let header = &ws_message.header;
    let app_id = header.app_id.as_str();
    let package_id = header.request_id.as_str();
    let file_index = meta_data.file_index;
    let chunk_index = meta_data.chunk_index;
    let key = format!("{}_{}_{}", app_id, package_id, file_index);
    let total_files = meta_data.total_files;

    println!("receive_byte_file_chunk, key: {}, chunk_index: {}", key, chunk_index);

    let entry = GLOBAL_BINARY_STREAM_CHUNK_CACHE.entry(key.clone()).or_insert_with(async {
        let name = meta_data.name.clone();
        let file_ext = meta_data.stream_type.clone();
        let length = meta_data.stream_length;
        let byte_chunk_map = DashMap::new();
        let byte_file_chunk = ByteFileChunk {
            file_index,
            name,
            file_ext,
            length,
            byte_chunk_map,
        };
        Arc::new(byte_file_chunk)
    }).await;

    entry.value().add_chunk(chunk_index, meta_data.chunk_binary_stream.unwrap());


    let file_chunk_ack = FileChunkAck::new(chunk_index, file_index, true, None);

    // 判断分块是否传输完毕
    return if meta_data.is_last_chunk && file_index == total_files - 1 {
        // 最后一个处理完毕
        Ok(FileChunkReceiveStatus::AllOk(file_chunk_ack))
    } else {
        Ok(FileChunkReceiveStatus::PartOk(file_chunk_ack))
    };
}
