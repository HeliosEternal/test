use std::sync::Arc;
use std::option::Option;
use crate::websocket::client_sender_manager;
use crate::websocket::model::build_ws_message::{build_error_response_ws_message, build_ok_response_ws_message, build_ws_error_response_ws_message};
use crate::websocket::handler::receive_file_chunk::receive_byte_file_chunk;
use crate::websocket::handler::router::{Router, ROUTER};
use crate::websocket::model::binary_stream_file::{ByteArrayMultipartFile, FileChunkReceiveStatus};
use crate::websocket::model::response_payload::FileChunkAck;
use crate::websocket::model::websocket_message::{FileStreamMetadata, MessageBody, WSMessage};
use crate::websocket::model::ws_message_error::WSMessageError;


const API_VERSION: &'static str = "/api/v1";

// 发送流分块的消息路由
const SEND_STREAM_CHUNK: &'static str = "/binary-stream/send-chunk/";

// 确认流分块的消息路由
const ACK_STREAM_CHUNK: &'static str = "/binary-stream/ack-chunk";


pub async fn dispatch_handler(router: &Router, mut ws_message: WSMessage) {
    println!("dispatch_handler: {}", ws_message.url);

    // 提前转移file_stream_metadata，避免后续无法获取所有权
    let file_stream_metadata_option = ws_message.take_file_stream_metadata();
    let arc_ws_message = Arc::new(ws_message);  // 包裹成Arc
    let request_url = arc_ws_message.url.as_str();

    // 分块传输消息处理
    if file_stream_metadata_option.is_some() {
        handle_file_chunk_transfer(file_stream_metadata_option, arc_ws_message.clone()).await;
        return;
    }

    // 处理确认分块消息
    if request_url.starts_with(ACK_STREAM_CHUNK) {
        handle_ack_chunk_message();
        return;
    }

    // 处理其他请求，调用对应的handler
    handle_request(router, request_url, arc_ws_message.clone()).await;
}

async fn handle_file_chunk_transfer(file_stream_metadata: Option<FileStreamMetadata>, arc_ws_message: Arc<WSMessage>) {
    let result = receive_file_chunk_handler(file_stream_metadata, arc_ws_message.clone()).await;
    match result {
        Ok(file_chunk_receive_status) => match file_chunk_receive_status {
            FileChunkReceiveStatus::PartOk(ws_message) => {
                println!("接收到部分分块，发送确认消息");
                send_response(ws_message);
            }
            FileChunkReceiveStatus::AllOk(ws_message) => {
                println!("接收到全部分块，开始执行业务handler");
                send_response(ws_message.clone());
                let request_url = arc_ws_message.url.as_str();
                let response = call_handler(request_url, &arc_ws_message).await;
                handle_response(response, arc_ws_message).await;
            }
        },
        Err(error) => handle_chunk_transfer_error(arc_ws_message, error),
    }
}

fn handle_chunk_transfer_error(arc_ws_message: Arc<WSMessage>, error: anyhow::Error) {
    println!("receive_file_chunk_handler error: {}", error);
    let error_message = build_error_response_ws_message(arc_ws_message, error);
    send_response_to_client(error_message);
}

fn handle_ack_chunk_message() {
    println!("接收到对方确认分块消息");
}

async fn handle_request(router: &Router, request_url: &str, arc_ws_message: Arc<WSMessage>) {
    let response = call_handler(request_url, &arc_ws_message).await;
    handle_response(response, arc_ws_message).await;
}

async fn handle_response(result: anyhow::Result<WSMessage>, arc_ws_message: Arc<WSMessage>) {
    match result {
        Ok(ws_message) => send_response(ws_message),
        Err(error) => {
            println!("处理handler时出错: {:?}", error);
            let error_message = build_error_response_ws_message(arc_ws_message, error);
            send_response_to_client(error_message);
        }
    }
}

async fn call_handler(request_url: &str, arc_ws_message: &Arc<WSMessage>) -> anyhow::Result<WSMessage> {
    println!("call_handler: {}", request_url);
    let handler_result = ROUTER.get_route_handler(request_url);

    match handler_result {
        Some(handler) => handler(arc_ws_message.clone()).await,
        None => {
            println!("未找到的处理器函数: {}", request_url);
            Ok(build_ws_error_response_ws_message(arc_ws_message.clone(), WSMessageError::not_found()))
        }
    }
}

fn send_response(ws_message: WSMessage) {
    ws_message.take_file_stream_metadata()
    match &ws_message.body {
        MessageBody::Response(response_body) => match &response_body.file_stream_data_vec {
            None => send_response_to_client(ws_message),
            Some(file_vec) => {
                // 分块传输逻辑处理
                println!("准备分块传输数据");
                // 分块传输逻辑的实现留待具体补充
            }
        },
        _ => {
            println!("send_response: ws_message.body 不是 Response");
        }
    }
}

fn send_response_to_client(ws_message: WSMessage) {
    println!("send_response_to_client: {}", ws_message.url);
    client_sender_manager::GLOBAL_CLIENT_SENDER_MANAGER.send_response(ws_message);
}

pub async fn receive_file_chunk_handler(
    file_stream_metadata:  Option<FileStreamMetadata>,
    arc_ws_message: Arc<WSMessage>,
) -> anyhow::Result<FileChunkReceiveStatus<WSMessage>> {
    let receive_chunk_result = receive_byte_file_chunk(file_stream_metadata, arc_ws_message.clone()).await;
    match receive_chunk_result {
        Ok(file_chunk_status) => {
            let header = arc_ws_message.header.clone();
            match file_chunk_status {
                FileChunkReceiveStatus::PartOk(value) => {
                    let ack_message = build_ok_response_ws_message(ACK_STREAM_CHUNK, header, Some(value));
                    Ok(FileChunkReceiveStatus::PartOk(ack_message))
                }
                FileChunkReceiveStatus::AllOk(value) => {
                    let ack_message = build_ok_response_ws_message(ACK_STREAM_CHUNK, header, Some(value));
                    Ok(FileChunkReceiveStatus::AllOk(ack_message))
                }
            }
        }
        Err(error) => {
            println!("receive chunk failed: {}", error);
            Err(error)
        }
    }
}
