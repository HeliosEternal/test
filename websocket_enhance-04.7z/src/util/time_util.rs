use chrono::Local;

pub fn get_milli_datetime() -> String {
    // 获取当前时间
    let now = Local::now();
    // 格式化时间，精确到毫秒
    now.format("%Y-%m-%d %H:%M:%S:%3f").to_string()
}


pub fn get_datetime() -> String {
    // 获取当前时间
    let now = Local::now();
    // 格式化时间，精确到毫秒
    now.format("%Y-%m-%d %H:%M:%S").to_string()
}



#[test]
pub fn test_get_milli_datetime() {
    println!("{}", get_milli_datetime());
    println!("{}", get_datetime());
}