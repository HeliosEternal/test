use std::io;
use std::path::PathBuf;
use std::str::FromStr;
use log::error;
use memmap2::{Mmap, MmapOptions};
use serde_json::json;
use tokio::fs;
use tokio::fs::File;
use tokio::sync::mpsc;
use tokio_stream::{Stream, StreamExt};
use tokio_stream::wrappers::ReceiverStream;
use websocket_enhance::util::hash_util::hash_bytes;
use websocket_enhance::util::time_util::get_milli_datetime;
use websocket_enhance::websocket::handler::request_handler;
use websocket_enhance::websocket::handler::router::{hello, UserInfo, Router, ROUTER};
use websocket_enhance::websocket::model::binary_stream_file::ByteArrayMultipartFile;
use websocket_enhance::websocket::model::request_payload::RequestBody;
use websocket_enhance::websocket::model::response_payload::ResponseBody;
use websocket_enhance::websocket::model::websocket_message::{Header, MessageBody, FileStreamMetadata, WSMessage};

const CHUNK_SIZE: usize = 1024 * 1024 * 10; // 1MB 分块大小

pub async fn handle_file_upload(file: request_handler::File) -> anyhow::Result<WSMessage> {
    println!("receive request: {}", "file.0.unwrap().len()");
    println!("receive request: {:?}", file.0.unwrap().len());
    let ws_message = WSMessage {
        header: Header {
            app_id: "".to_string(),
            request_id: "".to_string(),
            version: 0,
            created_date: 0.0.to_string(),
            ext_data: None,
        },
        url: "/404".to_string(),
        body: MessageBody::Response(
            ResponseBody {
                code: 200,
                msg: Option::from("success".to_string()),
                data: Some(
                    json!({
                        "name": "lanwenxi",
                        "age":15,
                        "address": "湖北省武汉市"
                    })
                ),
                file_stream_data: None,
            }),
        file_stream_metadata: None,
    };
    Ok(ws_message)
}


#[tokio::test]
pub async fn test2() {
    ROUTER.add_route("/upload", handle_file_upload);
    let user = UserInfo {
        name: "test".to_string(),
        age: 18,
        address: "beijing".to_string(),
    };
    let json_value = json!(user);

    let mut ws_message = WSMessage {
        header: Header {
            app_id: "".to_string(),
            request_id: "".to_string(),
            version: 0,
            created_date: 0.0.to_string(),
            ext_data: None,
        },
        url: "/upload".to_string(),
        body: MessageBody::Request(
            RequestBody {
                data: json_value,
            }
        ),
        file_stream_metadata: None,
    };

    let file_path = "H:\\temp-file\\VID_20230717_182637.mp4";

    let mut ss = transfer_file_chunk_into_metadata(file_path).await.unwrap();
    while let Some(chunk_result) = ss.next().await {
        match chunk_result {
            Ok(chunk_meta_data) => {
                println!("Chunk Meta Data: {:?}", chunk_meta_data);
                let mut ws_message_clone = ws_message.clone();
                ws_message_clone.file_stream_metadata = Some(chunk_meta_data);
                ROUTER.handle_request(ws_message_clone).await;
            }
            Err(e) => {
                error!("Error occurred while reading chunk stream: {}", e);
            }
        }
    }


    /*   let ws_msg = router.handle_request(ws_message).await;
       match ws_msg {
           Ok(msg) => {
               println!("响应结果：{:?}", msg);
           }
           Err(e) => {
               println!("{:?}", e.to_string());
           }
       }*/
}


async fn transfer_file_chunk_into_metadata(file_path: &str) -> anyhow::Result<impl Stream<Item=anyhow::Result<FileStreamMetadata>> + Send> {
    // let file_path = "H:\\temp-file\\VID_20230717_182637.mp4";
    let path_buf = PathBuf::from_str(file_path).unwrap();
    let meta_data = path_buf.metadata().unwrap();

    let file_size = meta_data.len() as usize;
    // 向上取整的高效算法
    let chunk_total = (file_size + CHUNK_SIZE - 1) / CHUNK_SIZE;
    let basic_meta_data = FileStreamMetadata {
        total_files: 1,
        file_index: 0,
        name: path_buf.file_name().unwrap().to_string_lossy().to_string(),
        stream_type: path_buf.extension().unwrap().to_string_lossy().to_string(),
        stream_length: meta_data.len() as usize,
        chunk_total,
        chunk_index: 0,
        is_last_chunk: false,
        chunk_hash: "".to_string(),
        chunk_binary_stream: None,
    };
    let mut chunk_stream = transfer_file_in_chunks(file_path.to_string(), CHUNK_SIZE).await.unwrap();
    let (tx, rx) = mpsc::channel(100);

    let _ = tokio::spawn(async move {
        let mut chunk_index = 0;
        while let Some(chunk_result) = chunk_stream.next().await {
            match chunk_result {
                Ok(chunk) => {
                    // 分块校验
                    let chunk_hash = hash_bytes(chunk.as_slice());
                    println!("chunk_index:{}  Chunk Hash: {}, chunk size: {} bytes", chunk_index, chunk_hash, chunk.len());

                    let mut chunk_meta_data = basic_meta_data.clone();
                    chunk_meta_data.chunk_binary_stream = Some(chunk);
                    chunk_meta_data.chunk_index = chunk_index;
                    chunk_meta_data.chunk_hash = chunk_hash;
                    chunk_meta_data.is_last_chunk = chunk_index == chunk_total - 1;
                    chunk_index = chunk_index + 1;
                    tx.send(Ok(chunk_meta_data)).await.unwrap();
                }
                Err(e) => {
                    eprintln!("read chunk stream error: {:?}", e);
                    let e = anyhow::anyhow!("read chunk stream error: {:?}", e);
                    let _ = tx.send(Err(e)).await;
                    break;
                }
            }
        }
    });
    Ok(ReceiverStream::new(rx))
}


async fn transfer_file_in_chunks(
    file_path: String,
    chunk_size: usize,
) -> anyhow::Result<impl Stream<Item=anyhow::Result<Vec<u8>>> + Send> {
    let (tx, rx) = mpsc::channel(100);
    tokio::spawn(async move {
        let file = File::open(file_path).await;
        match file {
            Ok(file) => {
                let std_file = file.into_std().await;
                let mmap = unsafe { Mmap::map(&std_file).unwrap() };
                let file_size = mmap.len();

                let mut offset = 0;
                while offset < file_size {
                    let end = std::cmp::min(offset + chunk_size, file_size);
                    let chunk = mmap[offset..end].to_vec();
                    let send_result = tx.send(Ok(chunk)).await;
                    if let Err(err) = send_result {
                        eprintln!("send chunk error: {:?}", err);
                        let e = anyhow::anyhow!("send chunk error: {:?}", err);
                        let _ = tx.send(Err(e)).await;
                        break;
                    }
                    offset = end;
                }
            }
            Err(e) => {
                eprintln!("open file error: {:?}", e);
                let e = anyhow::anyhow!("open file error: {:?}", e);
                let _ = tx.send(Err(e)).await;
            }
        }
    });

    Ok(ReceiverStream::new(rx))
}


#[tokio::test]
pub async fn test1() {
    let mut router = Router::new();
    router.add_route("/test", hello);

    let user = UserInfo {
        name: "test".to_string(),
        age: 18,
        address: "beijing".to_string(),
    };
    let json_value = json!(user);

    let ws_message = WSMessage {
        header: Header {
            app_id: "".to_string(),
            request_id: "".to_string(),
            version: 0,
            created_date: get_milli_datetime(),
            ext_data: None,
        },
        url: "/test".to_string(),
        body: MessageBody::Request(
            RequestBody {
                data: json_value,
            }
        ),
        file_stream_metadata: None,
    };
    router.handle_request(ws_message).await;

}
